$ErrorActionPreference = 'Stop'
$project = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$evidence = Join-Path $project 'results\step03'
$xbuild = Join-Path $project 'sim\.build-step03-xsim'
$ibuild = Join-Path $project 'sim\.build-step03-iverilog'
$vivadoBin = 'C:\Xilinx\Vivado\2018.3\bin'
$iverilogBin = 'C:\iverilog\bin'
$python = 'C:\Users\32035\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'

New-Item -ItemType Directory -Force $evidence, $xbuild, $ibuild | Out-Null
$sources = @(
    'rtl\single_port_sync_ram.v',
    'rtl\address_generator.v',
    'rtl\data_generator.v',
    'rtl\memory_interface.v',
    'rtl\response_checker.v',
    'rtl\march_controller.v',
    'rtl\mbist_top.v',
    'tb\tb_mbist_top.sv'
) | ForEach-Object { Join-Path $project $_ }

Push-Location $xbuild
try {
    & (Join-Path $vivadoBin 'xvlog.bat') -sv $sources *> (Join-Path $evidence 'xsim_compile.log')
    if ($LASTEXITCODE -ne 0) { throw 'XSim compile failed' }
    & (Join-Path $vivadoBin 'xelab.bat') tb_mbist_top -s mbist_step03_snapshot *> (Join-Path $evidence 'xsim_elaborate.log')
    if ($LASTEXITCODE -ne 0) { throw 'XSim elaboration failed' }
    & (Join-Path $vivadoBin 'xsim.bat') mbist_step03_snapshot -runall *> (Join-Path $evidence 'xsim_run.log')
    if ($LASTEXITCODE -ne 0) { throw 'XSim run failed' }
} finally { Pop-Location }

Push-Location $ibuild
try {
    & (Join-Path $iverilogBin 'iverilog.exe') -g2012 -s tb_mbist_top -o mbist.vvp $sources *> (Join-Path $evidence 'icarus_compile.log')
    if ($LASTEXITCODE -ne 0) { throw 'Icarus compile failed' }
    & (Join-Path $iverilogBin 'vvp.exe') mbist.vvp *> (Join-Path $evidence 'icarus_run.log')
    if ($LASTEXITCODE -ne 0) { throw 'Icarus run failed' }
} finally { Pop-Location }

foreach ($name in @('xsim', 'icarus')) {
    $runLog = Join-Path $evidence ($name + '_run.log')
    & $python (Join-Path $project 'scripts\check_step03_trace.py') $runLog *> (Join-Path $evidence ($name + '_trace_check.log'))
    if ($LASTEXITCODE -ne 0) { throw "$name trace check failed" }
    Get-Content (Join-Path $evidence ($name + '_trace_check.log'))
}

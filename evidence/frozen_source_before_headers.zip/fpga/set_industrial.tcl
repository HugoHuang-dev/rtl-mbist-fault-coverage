# Run before implementation optimization for the board's -2I operating grade.
set_operating_conditions -grade Industrial
report_operating_conditions -grade

# FPGA 工程

[`board_top.v`](board_top.v) 接入 50 MHz 时钟、RESET、KEY0、LED 和同步 RAM；[`board_pins.xdc`](board_pins.xdc)定义管脚与时序约束。[Vivado 工程说明](vivado/README.md)列出工程入口，构建命令与实测结果见[v8～v9 报告](../docs/08_fpga_implementation.md)。

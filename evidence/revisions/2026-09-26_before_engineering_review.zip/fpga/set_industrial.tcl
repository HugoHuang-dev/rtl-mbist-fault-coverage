# -----------------------------------------------------------------------------
# Hugo's MBIST Project
# -----------------------------------------------------------------------------
# Author  : sunmingyin.huang@haw-hamburg.de
# Project : RTL-Based MBIST with Automated Fault-Coverage Evaluation
# File    : set_industrial.tcl
# Module  : set_industrial
# Created : 2026-09-24
# Revised : 2026-09-26
# Editor  : Sublime Text 3 (Build 3211), Tab Size (4)
# -----------------------------------------------------------------------------
# Run before implementation optimization for the board's -2I operating grade.
set_operating_conditions -grade Industrial
report_operating_conditions -grade

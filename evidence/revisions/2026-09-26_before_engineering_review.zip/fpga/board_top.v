// -----------------------------------------------------------------------------
// Hugo's MBIST Project
// -----------------------------------------------------------------------------
// Author  : sunmingyin.huang@haw-hamburg.de
// Project : RTL-Based MBIST with Automated Fault-Coverage Evaluation
// File    : board_top.v
// Module  : board_top
// Created : 2026-09-24
// Revised : 2026-09-26
// Editor  : Sublime Text 3 (Build 3211), Tab Size (4)
// -----------------------------------------------------------------------------
`timescale 1ns/1ps

// DaVinci XC7A35T board wrapper. The MBIST algorithm and RAM interface are
// the same 64x8 design verified in Steps 1-7. Buttons are active low; LEDs
// are active high according to the board schematic.
module board_top #(
    parameter integer DEBOUNCE_CYCLES = 500000
) (
    input  wire       sys_clk,
    input  wire       sys_rst_n,
    input  wire       key0,
    output wire [3:0] led
);
    // The first stage may be reset asynchronously by the pushbutton. The
    // second stage has no asynchronous control, so BRAM enable is changed only
    // on the clock edge (Vivado DRC REQP-1840).
    reg reset_meta;
    reg reset_sync;
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n)
            reset_meta <= 1'b0;
        else
            reset_meta <= 1'b1;
    end
    always @(posedge sys_clk)
        reset_sync <= reset_meta;
    wire core_rst_n = reset_sync;

    // KEY0 is pulled up and pressed low. Synchronize and debounce it before
    // presenting a single start pulse to the MBIST core.
    reg [1:0] key_sync;
    reg key_stable;
    reg [31:0] debounce_count;
    reg start_pulse;
    always @(posedge sys_clk) begin
        if (!core_rst_n) begin
            key_sync <= 2'b11;
            key_stable <= 1'b1;
            debounce_count <= 32'd0;
            start_pulse <= 1'b0;
        end else begin
            key_sync <= {key_sync[0], key0};
            start_pulse <= 1'b0;
            if (key_sync[1] == key_stable) begin
                debounce_count <= 32'd0;
            end else if (debounce_count == DEBOUNCE_CYCLES - 1) begin
                key_stable <= key_sync[1];
                debounce_count <= 32'd0;
                if (key_stable && !key_sync[1])
                    start_pulse <= 1'b1;
            end else begin
                debounce_count <= debounce_count + 1'b1;
            end
        end
    end

    (* mark_debug = "true" *) wire busy;
    (* mark_debug = "true" *) wire done;
    (* mark_debug = "true" *) wire pass;
    (* mark_debug = "true" *) wire fail;
    (* mark_debug = "true" *) wire [8:0] error_count;
    (* mark_debug = "true" *) wire [2:0] first_fail_phase;
    (* mark_debug = "true" *) wire [5:0] first_fail_addr;
    (* mark_debug = "true" *) wire [7:0] first_fail_expected;
    (* mark_debug = "true" *) wire [7:0] first_fail_actual;
    (* mark_debug = "true" *) wire req_valid;
    (* mark_debug = "true" *) wire req_ready;
    (* mark_debug = "true" *) wire req_write;
    (* mark_debug = "true" *) wire [5:0] req_addr;
    (* mark_debug = "true" *) wire [7:0] req_wdata;
    (* mark_debug = "true" *) wire rd_valid;
    (* mark_debug = "true" *) wire [7:0] rd_data;
    (* mark_debug = "true" *) reg [9:0] accepted_count;

    always @(posedge sys_clk) begin
        if (!core_rst_n || start_pulse)
            accepted_count <= 10'd0;
        else if (req_valid && req_ready)
            accepted_count <= accepted_count + 1'b1;
    end

    mbist_top u_mbist (
        .clk(sys_clk), .rst_n(core_rst_n), .start(start_pulse),
        .busy(busy), .done(done), .pass(pass), .fail(fail),
        .error_count(error_count), .first_fail_phase(first_fail_phase),
        .first_fail_addr(first_fail_addr), .first_fail_expected(first_fail_expected),
        .first_fail_actual(first_fail_actual),
        .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write),
        .req_addr(req_addr), .req_wdata(req_wdata),
        .rd_valid(rd_valid), .rd_data(rd_data)
    );

    // A 64x8 block RAM inferred from the already verified synchronous RAM.
    single_port_sync_ram u_bram (
        .clk(sys_clk), .rst_n(core_rst_n),
        .req_valid(req_valid), .req_ready(req_ready),
        .req_write(req_write), .req_addr(req_addr), .req_wdata(req_wdata),
        .rd_valid(rd_valid), .rd_data(rd_data)
    );

    assign led[0] = done;
    assign led[1] = pass;
    assign led[2] = fail;
    assign led[3] = busy;
endmodule

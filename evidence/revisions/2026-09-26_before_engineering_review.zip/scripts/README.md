# 自动化与审计脚本

| 版本 | 入口 | 功能 |
| --- | --- | --- |
| v1 | [`generate_march_reference.py`](generate_march_reference.py) | 生成 640 笔参考序列 |
| v4 | [`run_step04.py`](run_step04.py) | 独立检查器负面回归 |
| v5 | [`run_step05.py`](run_step05.py) | 故障 RAM 定向测试 |
| v6 | [`generate_fault_manifest.py`](generate_fault_manifest.py)、[`run_step06.py`](run_step06.py)、[`audit_step06.py`](audit_step06.py) | 清单、批量运行及原始记录审计 |
| v7 | [`evaluate_fault_coverage.py`](evaluate_fault_coverage.py) | 覆盖率和首次检测阶段评估 |
| v8～v9 | [`audit_step08.py`](audit_step08.py)、[`audit_step08_ila.py`](audit_step08_ila.py) | 实现报告与 ILA 数据审计 |

从工程根目录运行；命令和输入文件见各版本的[结果索引](../README.md)。

# -----------------------------------------------------------------------------
# Hugo's MBIST Project
# -----------------------------------------------------------------------------
# Author  : sunmingyin.huang@haw-hamburg.de
# Project : RTL-Based MBIST with Automated Fault-Coverage Evaluation
# File    : frozen_source.py
# Module  : frozen_source
# Created : 2026-09-26
# Revised : 2026-09-26
# Editor  : Sublime Text 3 (Build 3211), Tab Size (4)
# -----------------------------------------------------------------------------
"""Verify the original Step 6 source fingerprints after release headers are added."""

import hashlib
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "evidence" / "frozen_source_before_headers.zip"
CODE_SUFFIXES = {".v", ".sv", ".py", ".tcl", ".xdc", ".ps1"}
AUDITOR = "scripts/audit_step06.py"


def strip_release_header(data: bytes) -> bytes:
    lines = data.splitlines(keepends=True)
    if len(lines) >= 11 and b"Hugo's MBIST Project" in lines[1]:
        return b"".join(lines[11:])
    return data


def verify_step6_source_fingerprints(manifest: Path) -> int:
    lines = manifest.read_text(encoding="utf-8").splitlines()
    checked = set()
    with ZipFile(ARCHIVE) as frozen:
        archived_names = set(frozen.namelist())
        for line in lines:
            expected, name = line.split("  ", 1)
            if name in checked:
                raise ValueError(f"duplicate source fingerprint: {name}")
            checked.add(name)
            original = (frozen.read(name) if name in archived_names
                        else (ROOT / name).read_bytes())
            if hashlib.sha256(original).hexdigest().upper() != expected:
                raise ValueError(f"frozen source hash differs: {name}")
            current = (ROOT / name).read_bytes()
            if name != AUDITOR:
                comparable = (strip_release_header(current)
                              if Path(name).suffix in CODE_SUFFIXES else current)
                if comparable != original:
                    raise ValueError(f"source body differs from frozen evidence: {name}")
    return len(checked)

# -----------------------------------------------------------------------------
# Hugo's MBIST Project
# -----------------------------------------------------------------------------
# Author  : sunmingyin.huang@haw-hamburg.de
# Project : RTL-Based MBIST with Automated Fault-Coverage Evaluation
# File    : run_step08_board.py
# Module  : run_step08_board
# Created : 2026-09-25
# Revised : 2026-09-26
# Editor  : Sublime Text 3 (Build 3211), Tab Size (4)
# -----------------------------------------------------------------------------
"""Run the board wrapper's short functional regression on XSim and Icarus."""

import hashlib
import json
import subprocess
from pathlib import Path

from run_step04 import oracle_text


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT.parent.parent / "work" / "step08" / "board_sim"
OUT = ROOT / "results" / "step08" / "simulation"
RTL = [ROOT / "rtl" / name for name in (
    "address_generator.v", "data_generator.v", "memory_interface.v",
    "response_checker.v", "march_controller.v", "mbist_top.v",
    "single_port_sync_ram.v",
)]
SOURCES = RTL + [ROOT / "fpga" / "board_top.v",
                 ROOT / "tb" / "march_transaction_checker.sv",
                 ROOT / "tb" / "tb_board_top.sv"]


def run(args: list[str], cwd: Path, log: Path) -> str:
    process = subprocess.run(args, cwd=cwd, capture_output=True, text=True,
                             errors="replace", timeout=180)
    output = process.stdout + process.stderr
    log.write_text(output, encoding="utf-8")
    if process.returncode:
        raise RuntimeError(f"{log.name} failed with {process.returncode}: {output[-1000:]}")
    return output


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    results = {}
    for tool in ("icarus", "xsim"):
        directory = WORK / tool
        directory.mkdir(parents=True, exist_ok=True)
        (directory / "oracle.hex").write_text(oracle_text(), encoding="ascii")
        if tool == "icarus":
            compiler = r"C:\iverilog\bin\iverilog.exe"
            runner = r"C:\iverilog\bin\vvp.exe"
            run([compiler, "-g2012", "-s", "tb_board_top", "-o", "board.vvp",
                 *(str(path) for path in SOURCES)], directory, OUT / "icarus_compile.log")
            output = run([runner, "board.vvp"], directory, OUT / "icarus_run.log")
        else:
            bin_dir = Path(r"C:\Xilinx\Vivado\2018.3\bin")
            run([str(bin_dir / "xvlog.bat"), "-sv", *(str(path) for path in SOURCES)],
                directory, OUT / "xsim_compile.log")
            run([str(bin_dir / "xelab.bat"), "tb_board_top", "-s", "board_snapshot"],
                directory, OUT / "xsim_elaborate.log")
            output = run([str(bin_dir / "xsim.bat"), "board_snapshot", "-runall"],
                         directory, OUT / "xsim_run.log")
        if ("BOARD_TB_PASS rounds=2" not in output or
                output.count("BOARD_CASE_PASS ") != 2 or
                output.count("CHECKER_PASS run=1 requests=640") != 2 or
                "CHECKER_FAIL" in output):
            raise RuntimeError(f"{tool} did not complete both checked board runs")
        results[tool] = {"rounds": 2, "requests_per_round": 640,
                         "led_at_done": "0011", "status": "pass"}
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n",
                                       encoding="utf-8")
    (OUT / "source_sha256.txt").write_text("".join(
        f"{hashlib.sha256(path.read_bytes()).hexdigest().upper()}  "
        f"{path.relative_to(ROOT).as_posix()}\n" for path in SOURCES), encoding="utf-8")
    print("STEP08_BOARD_SIM_PASS tools=2 rounds_per_tool=2 requests_per_round=640")


if __name__ == "__main__":
    main()

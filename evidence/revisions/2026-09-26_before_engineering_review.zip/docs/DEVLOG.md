# 开发日志

按版本整理 v1～v9 的工作与验收结果。v9 板卡照片与 ILA 于 **2026-09-26** 采集。原始结果见各版本证据目录。

| 阶段区间 | 工作 |
| --- | --- |
| 09.02–09.03 | v1 规格与 March C− 参考序列 |
| 09.04–09.06 | v2 单端口同步 RAM、独立测试与工具定版 |
| 09.07–09.10 | v3 March C− 控制器 RTL |
| 09.11–09.13 | v4 独立检查器与负面回归 |
| 09.14–09.17 | v5 故障存储器模型与定向验收 |
| 09.18–09.21 | v6 全量故障注入实验 |
| 09.22–09.23 | v7 独立故障覆盖率评估 |
| 09.24–09.25 | v8 Vivado 离线实现、位流与 ILA 配置 |
| 09.26 | v9 真实板卡采集、审计与总 README 归档 |

## v1 · 09.02–09.03 — 存储器规格与 March C−

**依据**：项目规划 V1.0；参考 R1 的 March C− 操作次序和同步读控制思路、R2 的模块化方向。板卡约束依据达芬奇开发板原理图 V2.1 与官方管脚表。

**完成**

1. 冻结第一版受测 RAM：64×8、6 位地址、50 MHz、单端口同步读。原始 `DaVinci_FPGA_IO.xdc` 记录 `create_clock -period 20.000` 且 `sys_clk` 位于 R4。
2. 定义统一请求/读响应接口，明确请求接受沿、下一上升沿消费读响应、读有效标志、写无响应及同地址读后写顺序。
3. 写出 M0～M5 阶段、地址方向、期望数据和所有阶段边界；生成完整的 640 笔逐笔请求 CSV。
4. 明确首次失效锁存、错误次数、测试继续执行和 DONE/PASS 的语义；区分 640 次操作与实际时钟周期。
5. 建立 v1～v9 的系统结构与版本演进索引。

**验证记录**：使用 Python 3 运行 `scripts/generate_march_reference.py`，脚本退出码 0，输出 `Wrote 640 requests`；独立 shadow RAM 检查全部读期望，阶段长度为 `64/128/128/128/128/64`，读/写为 `320/320`。另用 PowerShell `Import-Csv` 独立检查 CSV 的阶段首末：M0 `0/write/0 → 63/write/63`，M1 `0/read/64 → 63/write/191`，M2 `0/read/192 → 63/write/319`，M3 `63/read/320 → 0/write/447`，M4 `63/read/448 → 0/write/575`，M5 `0/read/576 → 63/read/639`。CSV SHA-256：`C23B52F26CCAD42CA485AF0FB77DA0F170C0F8467BF9B80712ECD4BE1A659B31`。

**技术记录**：此时冻结了 RAM 读时序和 640 笔参考序列；RAM 映射、故障模型及板级行为分别在对应版本中验证。

## v2 · 09.04–09.05 — 单端口 RAM 与独立读写测试

**依据**：v1 冻结的 64×8 RAM 接口和一拍读响应约定；R1 `march_c-/sim_models/memory_model.v`、net10 RAM 教学示例中的 `top.v` 与 `blk_mem_gen_0.xci`，以及 AMD UG473、XPM 文档。教学示例为 128×16、单端口、读延迟 1，不直接沿用其尺寸、FSM 或额外等待状态。

**完成**

1. 独立实现 `rtl/single_port_sync_ram.v`：同步单端口读写、无故障、无阵列初值/复位、正常周期请求总可接受；写无读响应，读响应与读数据同沿更新。
2. 建立 `tb/tb_single_port_sync_ram.sv`，用独立 shadow RAM 检查读值和响应时序。覆盖 0/63 边界、64 地址连续写读、同地址交替操作、空闲输出保持、复位取消请求和数据保留。
3. 提供 Vivado RAM-only 综合检查脚本；v2 详细验收记录见 `02_ram_verification.md`。

**初次验证记录**：Icarus Verilog `-g2012` 执行通过，输出 `RAM_TB_PASS checks=146 reads=70 writes=68`；Vivado XSim 2018.3 对相同 RTL/Testbench 执行通过，输出相同。Vivado 2018.3 对 `xc7a35tfgg484-2` 的 RAM-only 综合显示 1 个 `RAMB18E1`，`DOA_REG=0`、`WRITE_MODE_A=NO_CHANGE`。板卡丝印的工业温度等级后来按 7 系列 Vivado 的独立 operating grade 设置复核，见下方最终验收记录。

**实现时修正**：Testbench 最初把安排的读次数少算 1 次，已调整预期为 70；Vivado XSim 要求设计各模块声明一致的 timescale，已在 RAM RTL 添加 `` `timescale 1ns/1ps``。修正后重新运行得到上述通过结果。

**接口复用**：v3 控制器与 v4 独立检查器均使用此版 RAM 请求/响应接口。

## v2 · 09.06 — RAM 验收与仿真环境

**工具决定**：Vivado XSim 作为主仿真工具，Icarus Verilog 作为独立交叉验证工具；项目 README 与仿真说明同步更新。

**时序复核**：保留原 RAM 实现；Testbench 增加在下一时钟上升沿 NBA 更新前检查上一读响应的断言。原有 `#1` 沿后检查验证请求接受沿后输出，半周期改地址检查验证无异步提前变化。三处观察点确认读请求在 `E_k` 接受、数据在该沿后有效，并在 `E_{k+1}` 被同步控制器消费。

**最终运行**：XSim 2018.3 和 Icarus Verilog 11.0 分别从独立构建目录重新编译、运行相同源码，均以退出码 0 和 `RAM_TB_PASS checks=146 reads=70 writes=68` 结束。两个日志均列出四类 `CASE_PASS`：边界/稀疏访问、64 地址连续写读、交替写读与空闲保持、复位禁止写入且保留数据。原始编译/运行日志及复现命令存放在 `results/step02/`。

**目标器件综合**：板卡规格书为 `XC7A35TFGG484-2I`。按 AMD 7 系列 Vivado 的器件表示，综合选择 `xc7a35tfgg484-2`（器件、封装、速度级），综合设计打开后再设置 `set_operating_conditions -grade Industrial`；报告显示 `Device Grade = industrial`。Vivado 2018.3 RAM-only 综合得到 `RAMB18E1 × 1`、`DOA_REG=0`、`WRITE_MODE_A=NO_CHANGE`，0 errors/critical warnings/warnings。综合日志和利用率报告已保存。综合结构与 RTL 的读沿后更新、写时输出保持一致；尚未进行板级下载或完整工程时序收敛。

**结论**：v2 的 RAM 功能与结构验收完成，详细范围见 `02_ram_verification.md`。

## v2 · 09.06 — 工具版本定版

**决定**：项目统一使用 Vivado 2018.3，XSim 2018.3 为主仿真工具，Icarus Verilog 为交叉验证工具。板卡资料目录名中的 `2020.2` 不构成工程升级要求。

**依据与范围**：v2 已用 Vivado 2018.3 在目标器件上完成 RAM-only 综合，XSim 2018.3 与 Icarus 均通过独立 RAM Testbench。完整工程继续使用相同的 Vivado 版本。

## v3 · 09.07–09.10 — March C− 控制器 RTL

**依据**：v1 冻结的 64×8 RAM 请求/响应接口、M0～M5 共 640 笔请求及故障后继续测试语义；v2 已验证的一拍同步读 RAM。阅读 R1 `march_c-/rtl/` 的 FSM、地址发生器、数据发生器、比较器和顶层，参考模块职责；未沿用 R1 的错误提前退出逻辑。

**完成**：新增 `rtl/march_controller.v`、`address_generator.v`、`data_generator.v`、`memory_interface.v`、`response_checker.v` 和 `mbist_top.v`。控制器等候 `req_ready` 接受请求；读操作进入等待状态，只在 `rd_valid` 时比较，读写阶段在同地址完成读后写。错误信息首次锁存，错误次数累加，测试仍走完 M5 最后一次读比较；DONE 后结果保持，可再次启动。

**验证与证据**：`tb/tb_mbist_top.sv` 连接 v2 RAM，逐笔检查阶段、地址、读写及写数据；`scripts/check_step03_trace.py` 将 XSim 和 Icarus 输出分别与 `specs/march_c_minus_64x8.csv` 全部 640 行比对。`sim/run_step03.ps1` 从独立构建目录运行两套仿真，退出码 0，两个日志均有 `MBIST_TB_PASS` 和 `TRACE_CHECK_PASS`。无故障轮为 640 笔（320 读、320 写）、961 周期、PASS、错误数 0。第二轮只在 M2 地址 7 的读响应翻转一位，得到 FAIL、首错期望 FF/实际 FE、错误数 1，但仍完成全部 640 笔。运行中额外 `start` 被忽略，DONE 结果保持，DONE 后可重新启动。原始日志与复现命令见 `results/step03/README.md`。

**实现时修正**：复现脚本在 Windows PowerShell 5.1 下生成 UTF-16LE 重定向日志，轨迹核对脚本现按 BOM 识别编码，保证保存的日志可直接复查。

**结论与范围**：v3 无故障 March C− 集成验收完成。单次响应扰动检查控制器的失效诊断路径，不计入故障覆盖率；详见 `03_mbist_rtl_verification.md`。

## v4 · 09.11–09.13 — 独立检查器与负面回归

**依据与设计**：沿用 v1 冻结的 640 行 CSV；不重复 v3 的离线比对程序。新增 `tb/march_transaction_checker.sv`，只观察 DUT 顶层请求、响应和结果端口，从 CSV 生成的 `oracle.hex` 读取期望事务，不访问控制器内部 FSM 或地址寄存器。检查读响应消费时机、首错诊断、完成时机、请求次序与数据；运行中重复 `start` 不重置检查器，DONE 后重新启动开始新一轮。

**负面测试**：`scripts/run_step04.py` 在临时工作目录中对正式 RTL 分别施加单点变异：地址方向反转、M1 读改写、M1 写 1 改 0、读请求时提前比较、M4 后提前 DONE、首错地址偏移。每次独立编译运行，不修改正式 RTL。每个变体均由 XSim 2018.3 和 Icarus Verilog 检出对应的检查器错误类别 1～6；正常基线在两种工具下均完成无故障与一次定向读响应扰动两轮。

**验收与证据**：共 14 个案例，2 个正常基线被接受、12 个负面变体被预期类别拒绝；自动报告 `results/step04/report.csv` 和 `report.json`，原始编译/展开/运行日志及由冻结 CSV 生成的 `oracle.hex` 均保存在同目录。负面案例的仿真进程可能仍返回 0，脚本以明确的 `CHECKER_FAIL code`、fatal 日志和无整轮通过标记联合判断，不把进程码 0 当作设计通过。复现方式与适用范围见 `04_independent_verification.md`。

**结论**：v4 完成。6 位地址接口无大于 63 的输入编码，因此本轮用地址方向错误验证顺序检查；额外请求也会被拒绝。未发生可观察结果的内部提前比较无法由黑盒端口监测；本次 RTL 提前比较变体产生了诊断提前变化，已被检出。

## v5 · 09.14–09.17 — 故障存储器模型

**故障契约**：配置 `fault_type`（0 无故障、1 SA0、2 SA1、3 Rising TF、4 Falling TF）、`fault_addr[5:0]` 和 `fault_bit[2:0]`，一次实验只含一个目标位。SA0/SA1 目标位被固定为 0/1，向相反值写入构成激活；转换故障要求目标位已知且实际尝试指定的 0→1 或 1→0。`fault_activated` 记录是否曾激活，`activation_count` 记录事件次数；均不等同 MBIST 检出或覆盖率。故障发生于 RAM 单元读写，不修改控制器结果。

**实现**：新增 `tb/fault_injector.sv`、`faulty_memory.sv`，维持 v1 同步 RAM 接口及读响应时序；同步复位仅清除响应有效和激活记录，不清除单元。正式 `rtl/` 未改。无效/未知故障类型在仿真中拒绝。SA0/SA1 首次写入前目标读出位已固定，其他未初始化位仍未知。

**独立验证**：`tb/tb_faulty_memory_unit.sv` 直接测试正常模式及四种故障的目标/非目标单元、相反方向和重复写入、读回、复位保留；新增 `tb/fault_reference_monitor.sv` 从外部请求维护自己的参考物理状态，逐拍核对集成时的 RAM 读值及激活事件。v4 `march_transaction_checker.sv` 原样接入，继续核对 640 笔请求、读响应和首错诊断。集成 Testbench 以物理模型与冻结 March 序列独立预定各故障的首错阶段、地址、期望/实际值及比较错误次数。

**运行证据**：`scripts/run_step05.py` 在 XSim 2018.3 和 Icarus 分别执行 7 个独立 RAM 案例、7 个 MBIST 集成案例，共 28 个定向运行，均 PASS；7 组集成结果在两工具间逐项一致。无故障返回 PASS 且无激活；SA0、SA1、Rising TF、Falling TF 都按预定条件激活并被检出，控制器仍完成 640 笔请求。另测 SA0 地址 63/位 7 与 Falling TF 地址 0/位 0。原始日志、`report.csv`、生成的事务表与复现命令见 `results/step05/README.md`。

**结论与边界**：v5 的定向配置验证了模型与集成行为；2,048 个实例的批量结果和覆盖率分别见 v6、v7。详细语义与结果见 `05_faulty_memory_model.md`。

## v6 · 09.18–09.21 — 自动化故障注入实验

**实验全集**：`scripts/generate_fault_manifest.py` 确定性生成四类 × 64 地址 × 8 位，共 2,048 个单故障实例；`F0000`～`F2047` 各指向唯一配置。先选取每类 8 个不同地址和数据位，共 32 个实例试运行。

**实现**：增加 `tb/tb_step06_campaign.sv` 和 `scripts/run_step06.py`，复用 v4 事务 checker 及 v5 独立故障参考监视器。故障 RAM 与参考监视器新增仅供实验使用的 `experiment_clear`，让同一编译快照连续运行多个实例时逐例恢复未初始化状态；每例还分别复位控制器和 checker，并检查起始状态。普通存储器复位语义不变。正式 MBIST `rtl/` 无修改。运行器每种仿真器编译一次，分块执行，并为异常块做二分重试至单实例，保留无效原因及原始日志。

**验收**：Vivado 2018.3 XSim 与 Icarus Verilog 的试运行得到 64 条有效记录；全量得到 4,096 条有效记录，覆盖清单中全部 2,048 个配置，两工具逐字段比对分歧 0。全量 4,096 条均有激活、检出和首次错误诊断，均完成 640 笔请求；无效实例 0。`scripts/audit_step06.py` 复核清单唯一性、结果数量、原始日志 SHA-256、源码指纹及工具配对；`F1023` 双工具重放与全量记录一致。为确认实验清零端口不影响 v5 语义，也重跑了既有 28 个定向案例，XSim 与 Icarus 全部通过，并更新 v5 源码指纹。CSV、JSONL、原始日志、审计结果和源码指纹见 `results/step06/README.md`。

**结论与范围**：v6 完成四类仿真单故障的全量实验，并保存覆盖率评估所需的原始记录。详细方法见 `06_automated_fault_campaign.md`。

## v7 · 09.22–09.23 — 故障覆盖率评估

**方法**：新增 `scripts/evaluate_fault_coverage.py`，只读取 v6 冻结清单、逐实例结果、64 份原始日志、源码指纹、工具一致性表及 v1 640 笔参考序列，不重跑仿真或修改 RTL。脚本按 2,048 个唯一 `fault_id` 计分母，要求同一实例两工具均有效、激活、检出且结果一致才计入确认检出；逐例核对日志 SHA-256、激活事件、checker 结果和首错诊断，并与 v6 汇总及审计记录对账。定向篡改一条 CSV 的首检阶段时，分析脚本会拒绝记录。

**结果**：四类各 512/512 确认检出，目标集合总计 2,048/2,048，均为 100.00%；未激活、激活未检出、仿真无效/失败及工具分歧均为 0。首检阶段分别为 SA1→M1，SA0/Rising TF→M2，Falling TF→M3；每类全部地址和位的阶段一致，首次失败地址与注入地址一致。v1 理论操作 640 笔（320 读、320 写），全量 4,096 条有效工具记录均有 640 请求和 v6 口径的 960 周期。与 v3 的 961 拍记录相差一个启动采样沿的计数口径，已在报告中说明。

**产物与范围**：分类覆盖率 CSV、阶段矩阵 CSV、逐实例评估 CSV、异常清单、效率 JSON、哈希清单与完整报告见 `results/step07/README.md` 和 `docs/07_fault_coverage_evaluation.md`。100.00% 只对 64×8 仿真 RAM 的四类单故障全集成立，不表示真实物理存储器总体覆盖率。

## v8 · 09.24–09.25 — 板级工程与离线实现

**设计**：沿用 64×8、640 请求及原 `mbist_top` RTL，新增板级顶层、KEY0 同步去抖、RESET 同步接入、LED0～3 指示和 ILA 用请求计数器；精简 XDC 按达芬奇原理图 V2.1 与官方管脚表核对。Vivado 2018.3 目标为 `xc7a35tfgg484-2`，Industrial 操作条件。未改 March C− 算法或 v6 故障实验。

**修正**：首次实现虽然满足时序，但 BRAM 使能路径触发 `REQP-1840` 异步控制警告；板级复位改为首级异步清零、第二级同步输出。重新综合、实现后该警告消失。按原理图补充 `CFGBVS=VCCO`、`CONFIG_VOLTAGE=3.3`，并只保留实际使用的 KEY0 输入。

**离线证据**：独立控制器综合为 48 LUT、40 寄存器、0 BRAM。完整基线实现为 99 LUT、62 寄存器、1×RAMB18E1，`DOA_REG=0`、`WRITE_MODE_A=NO_CHANGE`，WNS +14.628 ns；ILA 版 18 组探针、深度 1024，WNS +14.169 ns，位流及 `.ltx` 均已生成。两者满足 20 ns 约束。板级包装层两轮正常启动测试在 XSim、Icarus 中均通过独立 640 笔 checker。`scripts/audit_step08.py` 已核对报告、BRAM 参数、探针名、位流和关键文件指纹。具体报告见 `docs/08_fpga_implementation.md` 与 `results/step08/README.md`。

**版本产物**：v8 完成离线实现、位流和 ILA 配置；上板操作记录与照片模板见 `docs/08_board_bringup_steps.md` 和 `results/step08/hardware/hardware_observation.md`。实际板卡运行与 ILA 采集记录在 v9。

## v9 · 2026-09-26 — 板卡采集与证据归档

**板级运行**：保存了达芬奇开发板芯片丝印与连接照片，以及基线和 ILA 两种配置在 KEY0 启动后的 LED 状态照片。两张结果照片均显示 LED0/DONE、LED1/PASS 点亮，LED2/FAIL、LED3/BUSY 熄灭。Vivado 原生 `ILADATA.ila` 保存为 `results/step08/hardware/ila_capture/2026-09-26_march_c_minus_64x8_full_run.ila`；七张阶段波形截图按 M0～M5 转换顺序命名，照片和截图均保留原始图像内容。文件索引与 SHA-256 清单见 `results/step08/hardware/README.md`。

**独立审计**：`scripts/audit_step08_ila.py` 从原生 `.ila` 提取完整 1024 点 CSV/VCD，并将所有 640 次外部请求逐笔与 v1 冻结 CSV 核对，同时检查写数据、读响应数据及一拍响应时序。结果为 320 读、320 写；M0～M5 请求数依次 64、128、128、128、128、64。末笔 M5 地址 63 的请求在采样点 959，读响应在 960，首次 DONE/PASS 在 961，此后到 1023 保持 PASS；FAIL=0、错误数 0、BUSY=0。机器可读结果见 `results/step08/hardware/ila_audit.json`。

**结论与边界**：正常 BRAM 路径完成板级验收，含 50 MHz 时序、RAMB18E1 映射、LED 和完整 ILA 数据。RESET 灯态、重复启动、Hardware Manager 器件识别截图和板上受控 FAIL 路径未单独留证；物理存储器故障覆盖率未测试。



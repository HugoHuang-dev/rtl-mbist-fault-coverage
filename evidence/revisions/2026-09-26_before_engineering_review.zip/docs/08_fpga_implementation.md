# v8：Vivado 综合与 FPGA 上板验证记录

**v8 · 09.24–09.25：**完成 Vivado 综合、实现及 50 MHz 时序检查。**v9 · 09.26：**板卡按 KEY0 后显示 PASS，ILA 保存 1024 个采样点。板上未执行异常扰动和 FAIL 诊断测试。

## 设计与板卡接口

沿用 v1 冻结的 64×8、50 MHz、640 笔 March C− 配置及 v3 已验证的 `mbist_top` RTL；未改控制算法。新增 [`board_top.v`](../fpga/board_top.v)，连接同步读 RAM、RESET、KEY0、LED0～LED3，并增加按键同步去抖及 10 位请求计数器供 ILA 观察。原理图 V2.1 显示 RESET/KEY0 被 10 kΩ 上拉、按下接地，LED 高电平点亮；引脚和时钟由官方 `DaVinci_FPGA_IO.xdc` 核对后摘录到 [`board_pins.xdc`](../fpga/board_pins.xdc)。系统使用 `XC7A35TFGG484-2I` 对应的 Vivado part `xc7a35tfgg484-2`，实现按 Industrial 条件分析。

外部 RESET 首级可异步清零，第二级在 50 MHz 时钟沿同步改变核心复位。因此 BRAM 使能不会由异步复位寄存器直接驱动；修正前 Vivado 报出的 `REQP-1840` 警告在最终实现中已消失。KEY0 为低有效，同步并稳定 500,000 拍（约 10 ms）后产生单拍 `start`。LED0=DONE、LED1=PASS、LED2=FAIL、LED3=BUSY。测试只使用 KEY0，其他按键未接入工程。

## 存储器映射与读时序

完整板级综合确认**1 个 `RAMB18E1`**用于 64×8 MUT，`DOA_REG=0`、`WRITE_MODE_A=NO_CHANGE`，见 [`bram_configuration.txt`](../results/step08/base/bram_configuration.txt)。`DOA_REG=0` 表明未增加可选的 BRAM 输出寄存级；读请求在接受沿后使 `rd_data/rd_valid` 有效，控制器在下一上升沿采样，符合 v1、v2 的接口定义。板级包装层使用相同 RAM RTL 和接口，未把 64×8 改成 1024×16，因此理论操作数仍为 640。实测原始 ILA 在末笔读请求后下一采样点出现 `rd_valid`，再下一采样点出现 DONE，符合该时序。

## 资源与 50 MHz 时序

| 构建范围 | LUT | 寄存器 | BRAM | 实现 WNS |
| --- | ---: | ---: | --- | ---: |
| 独立控制器综合（无 RAM、IO） | 48 | 40 | 0 | 不适用：未放置布线 |
| 完整基线系统（含按键、LED、MUT；无 ILA） | 99 | 62 | 1×RAMB18E1 | +14.628 ns |
| 完整 ILA 系统（含调试核） | 1,928 | 2,933 | 2×RAMB36E1 + 2×RAMB18E1 | +14.169 ns |

三组资源数据对应不同构建范围。ILA 系统额外占用调试 BRAM 和逻辑；其中一个 RAMB18E1 用作 MUT。基线与 ILA 的 20 ns `sys_clk` 约束均满足，TNS=0；关键路径分别为控制状态到地址寄存器使能、复位同步寄存器到地址寄存器使能。报告见 [`base/implemented_timing_summary.rpt`](../results/step08/base/implemented_timing_summary.rpt)、[`ila/timing_summary.rpt`](../results/step08/ila/timing_summary.rpt) 和相邻 `critical_paths.rpt`。ILA 位流生成时有一条 RTSTAT-10 调试核内部警告，DRC 错误为 0，位流生成成功；板卡 ILA 采集也已完成。异步按键和复位经过板级同步处理。

## 离线功能检查与实际硬件结果

[`tb_board_top.sv`](../tb/tb_board_top.sv) 把去抖参数缩小用于短仿真；XSim 2018.3 和 Icarus 各运行两轮，外部 KEY0 触发后均由独立 checker 核对完整 640 笔事务并得到 LED0/LED1 亮的逻辑结果。原始日志与摘要见 [`simulation/`](../results/step08/simulation/README.md)。此处运行的是 RTL 模型，不是 FPGA 上的物理 BRAM。

已生成基线 `board_top.bit`，以及配对的 ILA `board_with_ila.bit`、`board_with_ila.ltx`。文件位置见[构建证据索引](../results/step08/README.md)。ILA 深度 1024，18 组探针包含阶段、地址、读写、读响应、请求计数、DONE/PASS/FAIL 和首错诊断。

板级照片包括[芯片与连接](../results/step08/hardware/photos/01_board_device_and_connections_post_program.jpg)、[基线运行后的 LED 状态](../results/step08/hardware/photos/02_baseline_after_key0_done_pass_leds.jpg)及[ILA 运行后的 LED 状态](../results/step08/hardware/photos/03_ila_after_key0_done_pass_leds.jpg)。两张运行结果照片均显示 LED0/LED1 亮、LED2/LED3 灭。原生 [ILA 采集](../results/step08/hardware/README.md)内含完整 1024 点数据。新增 [`audit_step08_ila.py`](../scripts/audit_step08_ila.py) 独立对照 v1 冻结的 640 行参考序列，逐笔核对阶段、地址、读写和数据，并检查读响应、计数与完成状态，结果为 `STEP08_HARDWARE_ILA_AUDIT_PASS`。

ILA 在样点 0 捕获启动；请求总数为 640（320 读、320 写），M0～M5 分别为 64/128/128/128/128/64。最后一次读请求在样点 959，响应在 960，首次 DONE/PASS 在 961，此后至样点 1023 均保持 DONE=1、PASS=1、FAIL=0、BUSY=0、错误数 0。以请求阶段计，硬件执行 960 个时钟间隔；从启动触发样点算到观察到 DONE 为 961 个样点差，区别是启动/结果采样边界。完整证据和截图索引见[板级实测证据](../results/step08/hardware/README.md)与[验证记录](../results/step08/hardware/hardware_observation.md)。该次实验未进行受控读响应扰动。

复现命令、工程文件、源码指纹及机器可读离线审计见 [`results/step08/README.md`](../results/step08/README.md)。实现后 Utilization Report 与 Timing Summary 均已保存；基线和 ILA 版在 20 ns（50 MHz）约束下的 WNS 分别为 +14.628 ns、+14.169 ns，TNS 均为 0。结合真实 BRAM 的完整 March C− ILA/LED 证据，v8 离线实现与 v9 板级正常测试均完成。RESET 灯态、重复启动和板级 FAIL 诊断路径没有单独实测记录。

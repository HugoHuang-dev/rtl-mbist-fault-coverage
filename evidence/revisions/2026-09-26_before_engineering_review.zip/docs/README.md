# 设计、验证与开发记录

从[总 README](../README.md)的 v1～v9 演进表进入各版本文档。[开发日志](DEVLOG.md)记录设计、修正及验收；[上板操作手册](08_board_bringup_steps.md)记录板卡操作。

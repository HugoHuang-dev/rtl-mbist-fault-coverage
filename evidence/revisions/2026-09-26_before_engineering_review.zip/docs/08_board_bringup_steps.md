# v9 上板操作手册（达芬奇 XC7A35T，Vivado 2018.3）

本手册记录基线位流与 ILA 位流的下载、按键测试和波形采集流程。2026-09-26 的板级实验数据见[硬件证据索引](../results/step08/hardware/README.md)。

## 0. 准备文件与接线

1. 使用 **Vivado 2018.3**，确认开发板上 FPGA 丝印为 `XC7A35TFGG484-2I`。若器件丝印不同，先拍照记录并停止下载，避免使用错误目标位流。
2. 连接开发板电源和 JTAG 下载线，按板卡资料的供电步骤上电。板卡原理图中的 RESET、KEY0 均为**按下低电平**；LED0～LED3 为**高电平点亮**。
3. 本工程使用 50 MHz 时钟 R4、复位 U2、KEY0 T1、LED0～LED3 的 R2/R3/V2/Y2。管脚来源为资料盘 `3_开发板原理图和硬件相关文件/DaVinci_FPGA_IO.xdc`；本项目使用的精简约束为 [`board_pins.xdc`](../fpga/board_pins.xdc)。

**照片 A**：开发板全景，显示供电、JTAG 连接和 FPGA 芯片丝印。对应[板卡照片](../results/step08/hardware/photos/01_board_device_and_connections_post_program.jpg)。

## 1. 打开 Vivado 工程并确认目标器件

1. 在 Vivado 2018.3 选择 **File → Open Project**，打开 `fpga/vivado/mbist_board.xpr`。工程结构见 [Vivado 工程说明](../fpga/vivado/README.md)。
2. 在 Project Manager 中确认顶层是 `board_top`，目标器件对应 `xc7a35tfgg484-2`；工业温度级 `-2I` 的操作条件已在构建脚本中设置为 `Industrial`。
3. 在 **Open Hardware Manager → Open Target → Auto Connect** 中确认检测到 `xc7a35t`。如果没有设备，检查开发板供电、JTAG 线及驱动。

**截图 B**：Vivado 工程目标器件和 Hardware Manager 中检测到的器件，建议保存 `03_hw_target.png`。

## 2. 先下载无 ILA 的基线位流，检查 LED

1. 在 Hardware Manager 中右键检测到的 FPGA，选择 **Program Device**，Bitstream 选择 `releases/mbist_base_64x8.bit`。文件清单见 [releases 说明](../releases/README.md)。这份位流包含控制器、64×8 片上 BRAM 和按键/LED 包装层。
2. 下载成功后按一下板上 **RESET**，再松开。等约 0.1 秒，LED0～LED3 应全灭。复位只是清除控制状态，不要求清除 BRAM 数据。
3. 按住 **KEY0 约 0.1～0.3 秒**再松开，确保超过约 10 ms 的去抖时间。MBIST 运行仅约 19 µs，因此 LED3（BUSY）可能短到肉眼看不到。待结果稳定后，预期 **LED0（DONE）与 LED1（PASS）亮，LED2（FAIL）与 LED3（BUSY）灭**。
4. 再按 KEY0 一次，检查测试能否重新执行并保持 LED0、LED1 亮。若灯态不同，记录实际状态。

| LED | 含义 | 完成正常测试后的预期 |
| --- | --- | --- |
| LED0 | DONE | 亮 |
| LED1 | PASS | 亮 |
| LED2 | FAIL | 灭 |
| LED3 | BUSY | 灭 |

**照片 C**：KEY0 后的稳定灯态见[基线结果照片](../results/step08/hardware/photos/02_baseline_after_key0_done_pass_leds.jpg)。RESET 灯态与 Program Device 界面没有独立图像记录。

## 3. 下载 ILA 位流并设置完整运行采集

1. 在 Hardware Manager 再次 **Program Device**，Bitstream 改为 `releases/mbist_ila_64x8.bit`，Debug Probes 选择同目录的 `mbist_ila_64x8.ltx`。两文件必须配对。
2. 展开识别到的 ILA。探针应包含 `start_pulse`、阶段 `phase`、`req_addr`、`req_valid`、`req_write`、`req_wdata`、`rd_valid`、`rd_data`、`accepted_count`、`done`、`pass`、`fail`、`error_count` 和首次错误诊断。若 ILA 未出现，先确认 `.ltx` 与位流配对并刷新器件。
3. ILA 深度为 **1024 samples**。设触发条件为 `start_pulse == 1`，并把 **Trigger Position 设为 0**（若界面以百分比表示则选 0%，从触发点开始记录，尽量保留整轮约 960 周期）。先点 **Run Trigger** 使 ILA 等待触发，再按 RESET、松开，随后按住 KEY0 约 0.1～0.3 秒再松开。不要在 Run Trigger 之前按 KEY0。
4. 采集完成后查看波形末尾：`accepted_count` 应达到 **640**，最后一阶段为 **M5**，最后请求地址为 **63**，最后读响应被消费后 `done=1`、`pass=1`、`fail=0`、`error_count=0`。整轮应依次出现 M0～M5；M0 递增写 0，M1/M2 递增读写，M3/M4 递减读写，M5 递增读。`rd_valid` 对应先前接受的读请求，控制器在下一时钟沿消费该响应。
5. 在 ILA 窗口保存完整波形数据（Vivado 的 **Export ILA Data** 或保存波形配置），并拍两张截图：触发与早期 M0/M1、末端 M5/DONE。截图中要显示信号名、时间轴以及末端的 `accepted_count=640`，不要只保存启动附近的波形。

查看波形时，将 `phase`、`req_addr`、`accepted_count` 设为十进制或无符号显示。`phase=0～5` 分别对应 M0～M5。按外部请求核对下表；读响应会晚于读请求，不能在同一个采样点要求二者同时出现。

| 阶段 | 地址方向 | 每个地址的请求顺序 | 请求数 |
| --- | --- | --- | ---: |
| M0（0） | 0→63 | 写 `00` | 64 |
| M1（1） | 0→63 | 读期望 `00`，写 `FF` | 128 |
| M2（2） | 0→63 | 读期望 `FF`，写 `00` | 128 |
| M3（3） | 63→0 | 读期望 `00`，写 `FF` | 128 |
| M4（4） | 63→0 | 读期望 `FF`，写 `00` | 128 |
| M5（5） | 0→63 | 读期望 `00` | 64 |

如果 ILA 已触发却没有覆盖末端 DONE，先记录当前截图和原始数据，检查 Trigger Position 是否为 0、采样深度是否仍为 1024，并重新执行一次。若 JTAG 无法识别器件，先保存报错截图并核对电源、JTAG 接线、驱动以及板上实际器件型号。

**证据 D**：七张阶段截图及原生 `.ila` 文件见[硬件证据索引](../results/step08/hardware/README.md)，其中包含完整 1024 个采样。导出时确认范围覆盖完整 1024 个样本。

## 4. 填写板级记录

将板卡丝印、JTAG 识别、编程状态、RESET 与 KEY0 后灯态、M0～M5 覆盖情况、请求数、DONE/PASS/FAIL 和异常记录在[板级验证记录](../results/step08/hardware/hardware_observation.md)。如果 ILA 未覆盖 DONE，应保存波形并检查触发位置和设计；阶段顺序以 ILA 数据为准。

已保存的板级实验只覆盖正常 BRAM 的 March C− 测试。受控读响应扰动如单独实施，应使用独立位流并标注为人为逻辑扰动。

## 5. 可对照的已完成离线证据

- [控制器独立综合资源](../results/step08/controller/utilization.rpt)：48 LUT、40 寄存器、0 BRAM。
- [基线完整系统实现资源](../results/step08/base/implemented_utilization.rpt)：99 LUT、62 寄存器、1 个 RAMB18E1；包含按键、LED 包装，不含 ILA。
- [基线时序报告](../results/step08/base/implemented_timing_summary.rpt)：20 ns 约束、WNS +14.628 ns，设计时序约束满足。
- [BRAM 配置](../results/step08/base/bram_configuration.txt)：`RAMB18E1`、`DOA_REG=0`、`WRITE_MODE_A=NO_CHANGE`，与前述同步读接口一致。
- [板级包装仿真结果](../results/step08/simulation/summary.json)：XSim 和 Icarus 各两轮正常测试，均有 640 笔请求；这不是板级实测。

64×8 配置的理论请求数为 640。ILA 位流引入额外资源，其资源与时序见 `results/step08/ila/` 中的独立报告。ILA 实测末笔请求在采样点 959、读响应在 960、DONE/PASS 在 961，详见[独立审计](../results/step08/hardware/ila_audit.json)。

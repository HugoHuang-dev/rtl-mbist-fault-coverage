# 源码与实验记录

源码文件头标明所属版本日期和 2026-09-26 修订日期。RTL、Testbench、Python、Tcl、XDC 和 PowerShell 脚本采用统一项目抬头，注释符号按语言调整。

`fpga/vivado/` 内的 `.xpr`、缓存和运行脚本由 Vivado 生成，保留工具原有格式；人工编写的板级 RTL、Tcl 与 XDC 位于 `fpga/` 顶层。

| 文件 | 内容 |
| --- | --- |
| `frozen_source_before_headers.zip` | 加抬头前的源码与规格快照 |
| [`frozen_source_sha256.txt`](frozen_source_sha256.txt) | 快照内各文件的 SHA-256 |
| [`source_header_manifest.csv`](source_header_manifest.csv) | 源码版本日期、文件哈希和改动类型 |
| [`step07_source_sha256_before_headers.txt`](step07_source_sha256_before_headers.txt) | v7 评估时保存的原源码指纹 |
| [`step08_source_sha256_before_headers.txt`](step08_source_sha256_before_headers.txt) | v8 离线审计时保存的原源码指纹 |
| [`step08_hardware_sha256_before_packaging.txt`](step08_hardware_sha256_before_packaging.txt) | 工程整理前的板级证据文件校验清单 |
| [`release_checks/`](release_checks/README.md) | 当前源码的 XSim/Icarus 测试及审计运行日志 |

v6 的 `results/step06/source_sha256.txt` 保留实验时的源码指纹。[`audit_step06.py`](../scripts/audit_step06.py) 和 [`evaluate_fault_coverage.py`](../scripts/evaluate_fault_coverage.py)从源码快照校验这些指纹；对仅增加抬头的文件，还会比对源码正文。两份审计脚本增加了快照读取逻辑，因此在清单中标为 `audit_archive_support`。

工程整理时，工具日志和报告里的绝对构建目录统一为 `<PROJECT_ROOT>` 或 `<WORK_ROOT>`；测试标记、诊断和数值结果未改。v6 结构化记录的日志 SHA-256 已按整理后的文件重算，并通过 v6、v7 独立审计。Vivado 生成的工程脚本指向当前 ProjectIII 目录。

v2 README 列出当前源码 SHA-256。v3～v6 的源码指纹保留实验时的值，可通过源码快照复核。评估和离线审计重跑后，`results/step07/source_sha256.txt`、`results/step08/source_sha256.txt` 记录当前源码哈希；原值保存在上表的备份文件。板级证据索引更新后，`results/step08/hardware/sha256_manifest.txt` 也已重新计算。Vivado 工程文件 `fpga/vivado/mbist_board.xpr` 使用 ProjectIII 工程路径，源文件通过相对路径引用。

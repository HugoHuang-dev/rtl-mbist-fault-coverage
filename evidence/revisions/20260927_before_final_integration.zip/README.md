# 项目三：RTL MBIST 与自动故障覆盖率评估

**计划区间：2026.09.02–09.26 · 开发板：达芬奇 V2.1 / Artix-7 XC7A35TFGG484-2I**  
**工具：Verilog / SystemVerilog、Vivado 2018.3、XSim、Icarus Verilog、Python**

项目按存储器规格、RAM 验证、MBIST 控制器、独立检查器、故障模型、批量实验、覆盖率评估和 FPGA 上板的顺序实现。控制器入口为 [`mbist_top.v`](rtl/mbist_top.v)，板级顶层为 [`board_top.v`](fpga/board_top.v)。上板文件集中在[`releases/`](releases/README.md)：包含无 ILA 位流、ILA 位流和配套探针文件。

**结果：**March C− 共 640 笔请求（320 读、320 写）；四类单故障行为模型的 2,048 个实例均由 XSim 和 Icarus 检出；50 MHz 约束下，无 ILA 版 WNS 为 **+14.628 ns**，ILA 版为 **+14.169 ns**；板卡 LED 显示 PASS，原生 ILA 保存了 1024 个采样点。

当前源码已完成[工程复核与修订](docs/09_engineering_review.md)，新增可迁移构建、同步约束及 FAIL 演示位流。新构建已通过仿真和实现，尚未上板；下列板卡照片与 ILA 对应首次上板版本。实际构建与采集日期见原始报告。

## 系统设计

March C− 在 64 个地址上依次执行 `M0 ↑(w0)`、`M1 ↑(r0,w1)`、`M2 ↑(r1,w0)`、`M3 ↓(r0,w1)`、`M4 ↓(r1,w0)`、`M5 ↑(r0)`。`0` 为 `8'h00`，`1` 为 `8'hFF`；先完成同一地址的读与比较，再写入新值。六阶段共 `10 × 64 = 640` 笔请求。逐笔的地址、方向、操作和期望数据冻结在[参考序列 CSV](specs/march_c_minus_64x8.csv)中。

```text
板级：RESET / KEY0 → MBIST 控制器 → 单端口同步 BRAM
                          ↑                 │
                    读响应与比较 ←───────────┘
                          ↓
                   DONE / PASS / FAIL → LED + ILA

仿真：故障清单 → XSim / Icarus + 故障 RAM → 独立 Checker 与故障参考监视器
                                               ↓
                                  原始日志 → Python 审计 → 覆盖率与首检阶段
```

板级和仿真使用同一套控制器 RTL。Python 调用仿真器并分析日志；板级工程通过 LED 和 ILA 观察运行结果。故障覆盖率来自仿真故障 RAM，板级结果单独记录。

## 版本安排 · 2026.09.02–09.26

| 计划区间 | 版本 | 完成内容 | 证据 |
| --- | --- | --- | --- |
| 09.02–09.03 | **v1 规格与参考序列** | 固定 64×8、50 MHz、一拍同步读和六阶段 640 笔请求 | [规格](docs/01_memory_march_spec.md) · [逐笔 CSV](specs/march_c_minus_64x8.csv) |
| 09.04–09.06 | **v2 正常 RAM** | 单端口同步 RAM 与独立读写测试 | [RAM 验收](docs/02_ram_verification.md) · [原始日志](results/step02/README.md) |
| 09.07–09.10 | **v3 MBIST 控制器** | FSM、地址/数据发生器、响应比较与 PASS/FAIL 诊断 | [控制器说明](docs/03_mbist_rtl_verification.md) · [轨迹证据](results/step03/README.md) |
| 09.11–09.13 | **v4 独立检查器** | 外部事务检查和六类单点负面测试 | [验证设计](docs/04_independent_verification.md) · [回归报告](results/step04/README.md) |
| 09.14–09.17 | **v5 故障 RAM** | SA0、SA1、上升/下降转换故障及独立故障参考模型 | [模型定义](docs/05_faulty_memory_model.md) · [28 次定向测试](results/step05/README.md) |
| 09.18–09.21 | **v6 自动故障实验** | 2,048 实例清单、试运行、双工具全量回归与单例重放 | [实验方法](docs/06_automated_fault_campaign.md) · [原始记录](results/step06/README.md) |
| 09.22–09.23 | **v7 覆盖率评估** | 独立统计、异常对账、首次检测阶段矩阵 | [评估报告](docs/07_fault_coverage_evaluation.md) · [统计产物](results/step07/README.md) |
| 09.24–09.25 | **v8 FPGA 离线实现** | BRAM 推断、50 MHz 综合与布局布线、位流和 ILA 配置 | [实现报告](docs/08_fpga_implementation.md) · [构建证据](results/step08/README.md) |
| 09.26 | **v9 真实板卡验证** | KEY0 启动、LED 结果及 ILA 全程采集与逐笔审计 | [板级证据](results/step08/hardware/README.md) · [ILA 审计](results/step08/hardware/ila_audit.json) |

### v1–v2：存储器规格与 RAM 验证

v1 定义 `req_valid/req_ready` 请求握手、`rd_valid/rd_data` 读响应及 M0～M5 操作顺序。v2 实现 [`single_port_sync_ram.v`](rtl/single_port_sync_ram.v) 和独立的 [RAM Testbench](tb/tb_single_port_sync_ram.sv)。

**验证：**Testbench 在请求沿前、沿后及下一上升沿检查读数据与 `rd_valid`，避免非阻塞赋值的事件调度造成误判。XSim 与 Icarus 均通过 **146 项检查**，覆盖地址 0/63、连续与交替读写、空闲和复位内容保留。RAM-only 综合得到 **1 个 RAMB18E1，`DOA_REG=0`**；日志和命令见[v2 证据](results/step02/README.md)。

### v3：March C− 控制器集成

[`march_controller.v`](rtl/march_controller.v) 控制阶段和读后写顺序，地址、数据、请求接口和[`response_checker.v`](rtl/response_checker.v)分别实现相应功能。仅在 `rd_valid` 时比较读数据；发现错误后继续执行，到 M5 最后一次读比较后置位 DONE。

**验证：**XSim 和 Icarus 的无故障测试均记录 **640 笔请求、PASS**。在 M2 地址 7 扰动一次读响应后，控制器记录首错，继续完成 640 笔请求并返回 FAIL。请求轨迹逐笔对照 v1 的 CSV，通过 [`TRACE_CHECK_PASS`](results/step03/README.md)。该扰动用于检查诊断路径，不计入故障覆盖率。

### v4：独立检查器与负面测试

[`march_transaction_checker.sv`](tb/march_transaction_checker.sv) 检查控制器外部的 RAM 请求、读响应和结果端口。期望事务来自 v1 CSV；检查器不读取控制器内部 FSM。回归脚本在临时目录生成单点 RTL 变体。

**验证：**分别修改地址方向、读写顺序、写数据、比较时机、DONE 时机和首次错误地址。两工具合计 **14 个案例**：2 个基线通过，12 个变体被检查器按预期类别拒绝。回归同时核对错误类别、fatal 日志和通过标记，因为部分负面仿真的进程退出码仍为 0。结果见[回归报告](results/step04/report.csv)。

### v5：故障模型定向验证

[`faulty_memory.sv`](tb/faulty_memory.sv) 用故障类型、地址和位位置配置一个单故障；SA0/SA1 固定目标位，转换故障在满足指定旧状态和写入方向时激活。[`fault_reference_monitor.sv`](tb/fault_reference_monitor.sv) 根据外部读写维护独立参考状态。

**验证：**独立 RAM 测试核对目标位读回、状态转换及激活次数，再与控制器和 v4 检查器集成。XSim/Icarus 的 **28 次定向运行**全部通过；无故障模式返回 PASS，四类故障均按预期激活、检出并记录首错阶段与地址，控制器均完成 640 笔请求。配置和日志见[v5 证据](results/step05/README.md)。

### v6–v7：全量故障实验与覆盖率评估

v6 的[故障清单](results/step06/fault_manifest.csv)穷举四类 × 64 地址 × 8 位，共 **2,048 个唯一实例**。先试运行 32 个实例，再由 XSim 和 Icarus 各执行完整集合。运行器复用编译结果、分批运行，每例开始前清除实验状态，并保存逐例结果、原始日志、哈希及 `fault_id` 重放入口。MBIST RTL 未改动。

**验证：**结果记录分别保存激活、检出和仿真有效性；异常批次可拆分到单实例重跑。全量实验保存 **4,096 条有效工具记录**，2,048 对工具结果分歧为 0，无效记录为 0。审计与 `F1023` 重放通过。方法和原始数据见[实验索引](results/step06/README.md)。

**评估：**v7 的[`evaluate_fault_coverage.py`](scripts/evaluate_fault_coverage.py)读取故障清单、双工具记录和原始日志，以 **2,048 个唯一实例**作分母。两工具均有效、激活、检出且关键字段一致时计为确认检出。脚本核对日志哈希及首错字段；篡改一条 CSV 的首检阶段会使审计失败。统计见[覆盖率表](results/step07/coverage_by_type.csv)与[异常清单](results/step07/exceptions.csv)。

### v8–v9：FPGA 实现与板级验证

v8 增加板级包装模块，当前源码为 [`board_top.v`](fpga/board_top.v)，由同步去抖后的 KEY0 启动测试，LED0～3 分别表示 DONE、PASS、FAIL、BUSY。[管脚约束](fpga/board_pins.xdc)连接 50 MHz 时钟、按键和 LED。Vivado 2018.3 生成[工程](fpga/vivado/README.md)、无 ILA 位流和带 18 组探针的 ILA 位流。

**验证：**首次实现出现 `REQP-1840` 警告，原因是 BRAM 使能受异步复位路径影响。板级复位改为首级异步清零、第二级同步输出后，重新实现不再出现该警告。综合确认 **1 个 RAMB18E1、`DOA_REG=0`**；无 ILA 与 ILA 版均满足 20 ns 时钟约束。v9 于 **09.26** 上板：按 KEY0 后 LED0/LED1 点亮；[原生 ILA](results/step08/hardware/README.md)记录 640 笔请求，末笔读响应在样点 960，样点 961 首次 DONE/PASS。硬件轨迹逐笔对照 v1 CSV，通过[ILA 审计](results/step08/hardware/ila_audit.json)。[照片与波形](results/step08/hardware/README.md)均已保存。

## 最终量化结果

### 四类单故障的仿真覆盖率

| 故障类型 | 目标实例 | 双工具确认检出 | 首次检测阶段 |
| --- | ---: | ---: | --- |
| SA0 | 512 | 512 | M2 |
| SA1 | 512 | 512 | M1 |
| 上升转换故障 | 512 | 512 | M2 |
| 下降转换故障 | 512 | 512 | M3 |
| **合计** | **2,048** | **2,048（100.00%）** | [完整阶段矩阵](results/step07/detection_stage_matrix.csv) |

未激活、激活未检出、仿真无效和双工具分歧均为 0，逐实例可从[评估 CSV](results/step07/fault_evaluation.csv)追到[全量原始结果](results/step06/full/raw_results.csv)及对应日志。**100.00% 仅针对本项目 64×8 仿真 RAM 中这四类明确定义的单故障和 2,048 个配置**；不代表真实物理存储器的总体覆盖率，也不包括耦合故障或保持故障。

### 首次上板版本的 FPGA 资源、时序与实测

| 构建范围 | LUT | 寄存器 | BRAM | 50 MHz 实现后 WNS |
| --- | ---: | ---: | --- | ---: |
| 独立控制器综合 | 48 | 40 | 0 | 未放置布线 |
| 无 ILA 完整系统 | 99 | 62 | 1×RAMB18E1 | +14.628 ns |
| 带 ILA 完整系统 | 1,928 | 2,933 | 2×RAMB36E1 + 2×RAMB18E1 | +14.169 ns |

报告包括无 ILA 版的[资源](results/step08/base/implemented_utilization.rpt)与[时序](results/step08/base/implemented_timing_summary.rpt)，以及 ILA 版的[资源](results/step08/ila/utilization.rpt)与[时序](results/step08/ila/timing_summary.rpt)。20 ns 约束下两版 TNS 均为 0。ILA 逻辑和存储资源计入调试开销。板级[观察记录](results/step08/hardware/hardware_observation.md)与[ILA 审计](results/step08/hardware/ila_audit.json)显示 640 笔请求完整执行，最终 `DONE=1、PASS=1、FAIL=0`。板上未执行故障扰动；RESET 灯态、重复启动和 FAIL 路径未单独留证。

![ILA 末端：640 笔请求完成，DONE 与 PASS 置位](results/step08/hardware/ila_waveforms/07_m5_done_pass_640_requests.png)

## 复现与工程入口

工具配置、当前仿真和构建命令见[复现说明](docs/reproduce.md)。重新运行使用独立实验编号，输出写入项目内的 `.build/` 和 `results/reruns/`。

```powershell
$env:MBIST_RUN_ID = 'local_check_01'
py -3 scripts/run_step04.py
py -3 scripts/run_step05.py
py -3 scripts/run_step06.py --mode all
$env:MBIST_AUDIT_RUN_ID = $env:MBIST_RUN_ID
py -3 scripts/audit_step06.py
py -3 scripts/evaluate_fault_coverage.py
py -3 scripts/run_step06.py --mode replay --fault-id F0123
```

[本次软件复核](results/reruns/20260926_engineering_review/README.md)、[最终板级构建](results/reruns/20260926_review_final/README.md)、[正常与扰动位流](releases/20260926_review/README.md)。首次板级实测见[原始记录](results/step08/hardware/README.md)。

| 入口 | 内容 |
| --- | --- |
| [`specs/`](specs/README.md) | 冻结的 March C− 逐笔参考序列 |
| [`rtl/`](rtl/README.md) | 正常 RAM、MBIST 控制器及结果检查逻辑 |
| [`tb/`](tb/README.md) | RAM Testbench、独立事务 Checker、故障模型和参考监视器 |
| [`scripts/`](scripts/README.md) | 故障清单、回归、覆盖率与 ILA 数据审计 |
| [`fpga/`](fpga/README.md) | 板级顶层、XDC、[Vivado 工程](fpga/vivado/README.md)和构建脚本 |
| [`releases/`](releases/README.md) | 可直接下载的无 ILA/ILA 位流及探针文件 |
| [v2 RAM](results/step02/README.md)、[v3 控制器](results/step03/README.md)、[v4 独立验证](results/step04/README.md)、[v5 故障模型](results/step05/README.md) | 仿真与定向故障实验记录 |
| [v6 批量实验](results/step06/README.md)、[v7 覆盖率](results/step07/README.md) | 完整故障记录、独立评估报告 |
| [v8～v9 FPGA](results/step08/README.md) | 资源/时序报告、位流、板卡照片、原始 ILA 与审计 |
| [设计与验收文档](docs/README.md) | 各版本说明、[开发日志](docs/DEVLOG.md) |
| [`evidence/`](evidence/README.md) | 源码快照、SHA-256 与当前源码对应表 |

参考工程：[MBIST March Algorithms](https://github.com/Happy251005/mbist-march-algorithms)、[Politecnico di Torino Memory BIST](https://github.com/cad-polito-it/memory-bist)、[SRAM Controller UVM Verification](https://github.com/abdo-ehab-euv/sram-controller-uvm-verification)。项目接口、RTL、故障模型、统计脚本及板级工程见本仓库源码。耦合故障、March X 和 ASIC 实验未实施。

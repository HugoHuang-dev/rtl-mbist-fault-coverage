# 当前工程复现

在工程根目录打开 PowerShell。需要 Python 3.10 或以上、Vivado 2018.3 与 Icarus Verilog。脚本先定位工具并保存版本输出，找不到工具时直接报错。

## 工具配置

可在 PowerShell 中设置 `VIVADO_BIN` 和 `IVERILOG_BIN` 指向各自的 bin 目录，或将这些目录加入 PATH。本机已配置 `toolchain.local.json`；换电脑后修改其中的两个目录。优先级：环境变量 → 本机 JSON → PATH。

```powershell
$env:VIVADO_BIN = 'D:\Xilinx\Vivado\2018.3\bin'  # 示例，改为实际位置
$env:IVERILOG_BIN = 'D:\iverilog\bin'               # 示例，改为实际位置
```

## 仿真和全量实验

为一次实验选择新编号。同一编号下的重新运行会更新该轮结果；不要复用已经归档的编号。

```powershell
$env:MBIST_RUN_ID = 'local_check_01'
py -3 scripts/run_basic_sim.py
py -3 scripts/run_step04.py
py -3 scripts/run_step05.py
py -3 scripts/run_step06.py --mode all
$env:MBIST_AUDIT_RUN_ID = $env:MBIST_RUN_ID
py -3 scripts/audit_step06.py
py -3 scripts/evaluate_fault_coverage.py
py -3 scripts/run_step06.py --mode replay --fault-id F0123
```

输出为 `results/reruns/local_check_01/step02` 至 `step07`，构建文件为 `.build/local_check_01/`。`--mode all` 在每工具只编译一次的前提下执行试运行及全量实验。每次单例重放独立重新编译，并与同编号下的全量结果比对。

不设置 `MBIST_AUDIT_RUN_ID` 时，v6/v7 审计仍读取原 `results/step06`。历史源码指纹对照原始快照，当前 RTL/Testbench 正文另作一致性检查。新实验记录自己的源码快照与精确字节哈希。

## 板级仿真与构建

```powershell
$env:MBIST_RUN_ID = 'board_check_01'
py -3 scripts/run_step08_board.py
py -3 scripts/run_board_build.py --ila
py -3 scripts/run_board_build.py --fault --ila
py -3 scripts/audit_board_revision.py
```

同一轮分别产生 `base`、`ila`、`base_fault`、`ila_fault` 四个目录，含资源、时序、CDC、时序例外和同步链检查报告。正常/扰动的 `.bit/.ltx` 不可混用。生成的 Vivado 工程分别位于 `.build/board_check_01/vivado/` 和 `vivado_fault/`。

`audit_step08.py` 只核对首次上板版本的历史报告；当前修订使用 `audit_board_revision.py`。控制器源码不因板级扰动改变。

## 已执行的复核

- 软件与全量故障实验：`20260926_engineering_review`。
- 最终板级包装仿真及四个实现：`20260926_review_final`。
- 原始照片与 ILA：仍在 `results/step08/hardware/`。

结果汇总见[工程复核报告](09_engineering_review.md)。

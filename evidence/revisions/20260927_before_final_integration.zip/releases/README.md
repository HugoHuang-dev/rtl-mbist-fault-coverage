# 上板文件

| 文件 | 用途 | 原始构建文件 |
| --- | --- | --- |
| `mbist_base_64x8.bit` | LED 基线验证 | `results/step08/base/board_top.bit` |
| `mbist_ila_64x8.bit` | ILA 板级验证 | `results/step08/ila/board_with_ila.bit` |
| `mbist_ila_64x8.ltx` | ILA 探针配置，与上方位流配套 | `results/step08/ila/board_with_ila.ltx` |

三份文件与右列原始构建文件逐字节一致，校验值见[`SHA256.txt`](SHA256.txt)。上板步骤见[操作手册](../docs/08_board_bringup_steps.md)，实测照片和波形见[板级证据](../results/step08/hardware/README.md)。

新构建见[2026-09-26 修订版](20260926_review/README.md)，含正常和扰动的 LED/ILA 位流，尚未上板。上表三份文件仍对应原实测记录。

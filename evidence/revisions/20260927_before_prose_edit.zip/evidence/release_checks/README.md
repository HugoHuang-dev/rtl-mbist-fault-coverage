# 工程复核记录

以下检查使用 ProjectIII 当前源码。仿真构建文件位于系统临时目录，运行日志保存在本目录。

| 检查 | 结果 | 日志 |
| --- | --- | --- |
| Icarus 控制器集成测试 | 两轮各 640 笔请求；正常 PASS、响应扰动 FAIL；`MBIST_TB_PASS` | [`icarus_run.log`](icarus_run.log) |
| XSim 控制器集成测试 | 同上 | [`xsim_compile.log`](xsim_compile.log)、[`xsim_elaborate.log`](xsim_elaborate.log)、[`xsim_run.log`](xsim_run.log) |
| Vivado 2018.3 打开工程 | 器件 `xc7a35tfgg484-2`、顶层 `board_top`、8 个设计源文件 | [`vivado_open_project.log`](vivado_open_project.log) |
| v6 原始证据审计 | 2048 个故障实例、4096 条工具记录，PASS | [`step06_audit.log`](step06_audit.log) |
| v7 覆盖率评估 | 2048/2048 确认检出，PASS | [`step07_evaluation.log`](step07_evaluation.log) |
| v8 资源与时序审计 | 基线 WNS +14.628 ns，ILA WNS +14.169 ns，PASS | [`step08_offline_audit.log`](step08_offline_audit.log) |
| v9 ILA 数据审计 | 1024 采样、640 请求、DONE/PASS，PASS | [`step08_ila_audit.log`](step08_ila_audit.log) |

# 源码与实验记录

当前源码头保留作者、项目、文件和模块。当前代码字节校验见[源码 SHA256](current_source_sha256.txt)，本次修改前的源码与文档保存于 `revisions/2026-09-26_before_engineering_review.zip`，原始文件未回写。

| 文件 | 对应记录 |
| --- | --- |
| `frozen_source_before_headers.zip` | 首次工程整理前的源码快照 |
| [frozen_source_sha256.txt](frozen_source_sha256.txt) | 原快照成员的字节哈希 |
| [source_header_manifest.csv](source_header_manifest.csv) | 早期文件头整理清单，保留历史值 |
| [step07_source_sha256_before_headers.txt](step07_source_sha256_before_headers.txt) | 原评估源码哈希 |
| [step08_source_sha256_before_headers.txt](step08_source_sha256_before_headers.txt) | 原实现审计的源码哈希 |
| [step08_hardware_sha256_before_packaging.txt](step08_hardware_sha256_before_packaging.txt) | 原板级文件哈希 |
| [release_checks](release_checks/README.md) | 早期工程整理时的回归记录 |

历史 v6 的源码指纹对照原源码快照；当前 RTL/Testbench 正文还需与快照一致，仅忽略文件头和 CRLF/LF 差异。修订后的运行脚本由新实验单独记录，不能据历史实验宣称其已经运行。

新全量实验在 `results/reruns/20260926_engineering_review/step06/` 保存独立 `source_snapshot.zip`、`source_sha256.txt` 及原始日志。每条结构化记录包含原始日志哈希。当前板级实现见[复核报告](../docs/09_engineering_review.md)。

原工程整理时，部分日志的绝对构建目录被规范为 `<PROJECT_ROOT>` 或 `<WORK_ROOT>`；结果数值未改，日志哈希已重新计算。此次保留这些历史文件，新增运行日志保存工具原始输出。原生 ILA 保留原文件及哈希，可迁移副本另存。

## 终版核对

[板级资料](../results/step08/hardware_final/README.md)包括 17 份原始文件及五轮 ILA 审计。[工程检查](revisions/package_check.json)汇总链接、源码、发布文件和硬件核对结果；[终版 SHA-256 清单](revisions/20260927_final_sha256.txt)记录当前文档、源码和结果文件。

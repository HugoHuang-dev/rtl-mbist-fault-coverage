# Testbench 与故障模型

| 版本 | 主要文件 | 用途 |
| --- | --- | --- |
| v2 | [`tb_single_port_sync_ram.sv`](tb_single_port_sync_ram.sv) | RAM 读写与一拍响应检查 |
| v3 | [`tb_mbist_top.sv`](tb_mbist_top.sv) | 无故障 MBIST 集成测试 |
| v4 | [`march_transaction_checker.sv`](march_transaction_checker.sv) | 独立核对外部事务与诊断 |
| v5 | [`faulty_memory.sv`](faulty_memory.sv)、[`fault_injector.sv`](fault_injector.sv)、[`fault_reference_monitor.sv`](fault_reference_monitor.sv) | 单故障行为及参考监视 |
| v6 | [`tb_step06_campaign.sv`](tb_step06_campaign.sv) | 全量故障实验 |

各版本的测试输入、运行命令和结果见[总 README](../README.md)。

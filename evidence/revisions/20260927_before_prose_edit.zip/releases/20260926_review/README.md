# 板级发布文件

正常/扰动的 LED 与 ILA 配置均完成板级验证，双工具仿真及 50 MHz 实现通过。[板级结果与原生采集](../../results/step08/hardware_final/README.md)。

| 文件 | 模式 | 实测 LED0～3 |
| --- | --- | --- |
| `normal_led.bit` | 正常 BRAM，无 ILA | DONE/PASS 亮，FAIL/BUSY 灭 |
| `normal_ila.bit`、`normal_ila.ltx` | 正常 BRAM，带 ILA | 同上 |
| `fault_led.bit` | 单次读响应扰动，无 ILA | DONE/FAIL 亮，PASS/BUSY 灭 |
| `fault_ila.bit`、`fault_ila.ltx` | 单次读响应扰动，带 ILA | 同上 |

扰动配置：每轮第 72 次读响应翻转 bit 0，对应 M2 / 地址 7 / FF→FE。实测错误数 1，完整执行 640 笔请求。该模式验证逻辑诊断路径。

每套 `.bit/.ltx` 必须配对使用。文件校验见 [SHA256](SHA256.txt)，[实现及仿真审计](../../results/reruns/20260926_review_final/step08/revision_audit.json)，[修订说明](../../docs/09_engineering_review.md)。原上板版本继续保存在上级目录。

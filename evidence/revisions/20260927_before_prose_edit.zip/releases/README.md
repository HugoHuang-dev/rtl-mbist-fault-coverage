# 上板文件

[正常与受控扰动位流](20260926_review/README.md)为当前版本，均已完成板级测试。

| 模式 | 位流与探针 | 实测结果 |
| --- | --- | --- |
| 正常 LED | [normal_led.bit](20260926_review/normal_led.bit) | DONE/PASS |
| 正常 ILA | [normal_ila.bit](20260926_review/normal_ila.bit)、[normal_ila.ltx](20260926_review/normal_ila.ltx) | 三轮 PASS，每轮 640 请求 |
| 扰动 LED | [fault_led.bit](20260926_review/fault_led.bit) | DONE/FAIL |
| 扰动 ILA | [fault_ila.bit](20260926_review/fault_ila.bit)、[fault_ila.ltx](20260926_review/fault_ila.ltx) | 两轮 FAIL，首错 M2/地址 7/FF→FE，每轮 640 请求 |

[文件校验](20260926_review/SHA256.txt) · [操作手册](../docs/08_board_bringup_steps.md) · [板级证据](../results/step08/hardware_final/README.md)

## 初始正常版本归档

`mbist_base_64x8.bit`、`mbist_ila_64x8.bit`、`mbist_ila_64x8.ltx` 对应 [初始采集](../results/step08/hardware/README.md)，[校验清单](SHA256.txt)保留原值。

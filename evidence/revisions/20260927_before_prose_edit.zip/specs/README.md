# v1 规格与参考序列

[`march_c_minus_64x8.csv`](march_c_minus_64x8.csv) 固定 64×8 March C− 的 640 笔请求。字段记录阶段、地址、操作和数据；生成方法及接口时序见[设计规格](../docs/01_memory_march_spec.md)。

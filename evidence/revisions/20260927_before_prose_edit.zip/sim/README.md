# 仿真环境

项目工具版本固定为 Vivado 2018.3；主仿真工具为其 XSim 2018.3。交叉验证工具：Icarus Verilog。

v2 RAM Testbench 的命令、源码哈希与运行日志见[v2 证据](../results/step02/README.md)。完整 MBIST 和故障注入回归均使用 XSim 与 Icarus 验证。

v3 控制器集成测试可执行 [`run_step03.ps1`](run_step03.ps1)，其运行日志与 v1 CSV 逐笔核对结果见 [`../results/step03/README.md`](../results/step03/README.md)。

v4 独立检查器的正常与负面回归由 [`../scripts/run_step04.py`](../scripts/run_step04.py) 执行，报告和日志见 [`../results/step04/README.md`](../results/step04/README.md)。

v5 故障 RAM 的独立定向测试和 MBIST 集成测试由 [`../scripts/run_step05.py`](../scripts/run_step05.py) 执行，报告与原始日志见 [`../results/step05/README.md`](../results/step05/README.md)。

v6 由 [`../scripts/run_step06.py`](../scripts/run_step06.py) 使用 XSim 与 Icarus 执行 32 个试运行和 2,048 个全量故障实例。结果、原始日志、审计及单实例复现命令见 [`../results/step06/README.md`](../results/step06/README.md)。

# RTL 源码

- v2：[`single_port_sync_ram.v`](single_port_sync_ram.v)，单端口同步 RAM。
- v3：[`mbist_top.v`](mbist_top.v)、[`march_controller.v`](march_controller.v)、[`address_generator.v`](address_generator.v)、[`data_generator.v`](data_generator.v)、[`memory_interface.v`](memory_interface.v)、[`response_checker.v`](response_checker.v)，实现 March C− 控制与诊断。

接口与测试结果见 [v2](../docs/02_ram_verification.md) 和 [v3](../docs/03_mbist_rtl_verification.md)。

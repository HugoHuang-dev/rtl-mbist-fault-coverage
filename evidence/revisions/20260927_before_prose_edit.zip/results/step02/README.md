# v2 原始证据与复现命令

**v2 · 09.04–09.06**。本目录保存 RAM 仿真、综合日志及复现命令。使用的源码为 `rtl/single_port_sync_ram.v` 和 `tb/tb_single_port_sync_ram.sv`。

| 文件 | 内容 |
| --- | --- |
| `xsim_compile.log`、`xsim_elaborate.log`、`xsim_run.log` | XSim 独立编译、展开、运行输出 |
| `icarus_compile.log`、`icarus_run.log` | Icarus 独立编译、运行输出 |
| `vivado_ram_synth.log` | RAM-only 综合、工业温度级和 RAM 原语属性 |
| `ram_only_utilization.rpt` | Vivado 利用率：1 个 RAMB18E1 |

两套仿真均返回退出码 0，均输出 `RAM_TB_PASS checks=146 reads=70 writes=68` 和相同的四个 `CASE_PASS` 场景标记。综合返回退出码 0；关键行：`Device Grade = industrial`，`RAM_CHECK board=XC7A35TFGG484-2I vivado_part=xc7a35tfgg484-2 grade=Industrial primitive=RAMB18E1 DOA_REG=0 WRITE_MODE_A=NO_CHANGE`。

## 复现命令（PowerShell）

从项目根目录开始。构建目录由 `.gitignore` 忽略；将工具路径换成其他安装位置时保持参数不变。

```powershell
$project = (Get-Location).Path
$evidence = Join-Path $project 'results\step02'
New-Item -ItemType Directory -Force -Path $evidence | Out-Null

$xbuild = Join-Path $project 'sim\.build-xsim'
New-Item -ItemType Directory -Force -Path $xbuild | Out-Null
Push-Location $xbuild
& 'C:\Xilinx\Vivado\2018.3\bin\xvlog.bat' -sv (Join-Path $project 'rtl\single_port_sync_ram.v') (Join-Path $project 'tb\tb_single_port_sync_ram.sv') *> (Join-Path $evidence 'xsim_compile.log')
if ($LASTEXITCODE -ne 0) { throw 'xvlog failed' }
& 'C:\Xilinx\Vivado\2018.3\bin\xelab.bat' tb_single_port_sync_ram -s ram_tb_snapshot *> (Join-Path $evidence 'xsim_elaborate.log')
if ($LASTEXITCODE -ne 0) { throw 'xelab failed' }
& 'C:\Xilinx\Vivado\2018.3\bin\xsim.bat' ram_tb_snapshot -runall *> (Join-Path $evidence 'xsim_run.log')
if ($LASTEXITCODE -ne 0) { throw 'xsim failed' }
Pop-Location

$ibuild = Join-Path $project 'sim\.build-iverilog'
New-Item -ItemType Directory -Force -Path $ibuild | Out-Null
Push-Location $ibuild
& 'C:\iverilog\bin\iverilog.exe' -g2012 -s tb_single_port_sync_ram -o ram_tb.vvp (Join-Path $project 'rtl\single_port_sync_ram.v') (Join-Path $project 'tb\tb_single_port_sync_ram.sv') *> (Join-Path $evidence 'icarus_compile.log')
if ($LASTEXITCODE -ne 0) { throw 'iverilog failed' }
& 'C:\iverilog\bin\vvp.exe' ram_tb.vvp *> (Join-Path $evidence 'icarus_run.log')
if ($LASTEXITCODE -ne 0) { throw 'vvp failed' }
Pop-Location

$sbuild = Join-Path $project 'fpga\.build-ram'
New-Item -ItemType Directory -Force -Path $sbuild | Out-Null
Push-Location $sbuild
& 'C:\Xilinx\Vivado\2018.3\bin\vivado.bat' -mode batch -nojournal -notrace -source (Join-Path $project 'fpga\check_ram_inference.tcl') -tclargs XC7A35TFGG484-2I *> (Join-Path $evidence 'vivado_ram_synth.log')
if ($LASTEXITCODE -ne 0) { throw 'RAM synthesis failed' }
Copy-Item -LiteralPath 'ram_only_utilization.rpt' -Destination (Join-Path $evidence 'ram_only_utilization.rpt') -Force
Pop-Location
```

复查日志时，除进程退出码为 0，还应检查两个运行日志各有一个 `RAM_TB_PASS` 且不含 `FATAL`；综合日志应显示 `primitive=RAMB18E1 DOA_REG=0`。单纯看到 `$finish` 不代表测试通过。

## 当前源码 SHA-256

- `rtl/single_port_sync_ram.v`：`B60138AA0EB8A06110E1824E7C48B3828DCAF1815CB5A86E3B70DB6ED362E4A4`
- `tb/tb_single_port_sync_ram.sv`：`6A21A26113E4B193E1010D0360D953EA7F3401685F038F25C6CC01C3D10346D8`
- `fpga/check_ram_inference.tcl`：`13DBEF3543288B7FE1CB1160789FD117FC542991333BE8BAE265A71A3BD145EB`

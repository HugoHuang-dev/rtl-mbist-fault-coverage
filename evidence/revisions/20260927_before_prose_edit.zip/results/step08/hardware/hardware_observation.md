# v9 板级验证记录 · 2026-09-26

达芬奇 Artix-7 开发板分别运行基线位流和 ILA 位流。照片记录板卡连接及 LED 状态；原生 ILA 数据用于核对 March C− 的实际请求序列。文件清单见[板级证据索引](README.md)。

| 检查项 | 结果与证据 |
| --- | --- |
| 板卡与连接 | [板卡照片](photos/01_board_device_and_connections_post_program.jpg)显示 Artix-7 芯片丝印、电源和 JTAG 接线；工程目标为 `xc7a35tfgg484-2`，使用 Industrial 操作条件 |
| 基线运行 | 按 KEY0 后，[LED 照片](photos/02_baseline_after_key0_done_pass_leds.jpg)显示 LED0/DONE、LED1/PASS 亮，LED2/FAIL、LED3/BUSY 灭 |
| ILA 运行 | [LED 照片](photos/03_ila_after_key0_done_pass_leds.jpg)显示相同的完成状态；原生采集文件为 `ila_capture/2026-09-26_march_c_minus_64x8_full_run.ila` |
| 请求序列 | [导出波形](ila_capture/full_run_waveform.csv)与 v1 的 640 笔参考序列逐笔一致；M0～M5 请求数为 64、128、128、128、128、64，共 320 读、320 写 |
| 完成时序 | 样点 959 为 M5 地址 63 的末笔请求，960 出现读响应，961 首次 `DONE=1`、`PASS=1`；至样点 1023 保持 `FAIL=0`、`BUSY=0`、错误数 0 |
| 独立审计 | [审计结果](ila_audit.json)为 `STEP08_HARDWARE_ILA_AUDIT_PASS`；运行命令：`py -3 scripts/audit_step08_ila.py` |

本页归档正常 BRAM 的首轮 PASS 记录；完整的正常/扰动、复位与重复启动结果见[终版板级验收](../hardware_final/README.md)。

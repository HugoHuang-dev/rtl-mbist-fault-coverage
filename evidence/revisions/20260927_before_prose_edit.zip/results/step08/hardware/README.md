# v9 板级实测证据

本页为初始正常采集归档。[完整板级验收](../hardware_final/README.md)包含正常/扰动、复位及重复启动资料。

**v9 · 2026-09-26 板卡验证。**照片按拍摄顺序保存；`sha256_manifest.txt` 列出文件校验值。灯态及 ILA 分析见[板级验证记录](hardware_observation.md)。

## 板卡照片

| 顺序 | 文件 | 可见内容 |
| --- | --- | --- |
| 1 | [`01_board_device_and_connections_post_program.jpg`](photos/01_board_device_and_connections_post_program.jpg) | Artix-7 芯片丝印、供电与 JTAG 接线 |
| 2 | [`02_baseline_after_key0_done_pass_leds.jpg`](photos/02_baseline_after_key0_done_pass_leds.jpg) | 无 ILA 位流，按 KEY0 后 LED0/LED1 亮，LED2/LED3 灭 |
| 3 | [`03_ila_after_key0_done_pass_leds.jpg`](photos/03_ila_after_key0_done_pass_leds.jpg) | ILA 位流，按 KEY0 后同样显示 DONE/PASS |

## ILA 波形截图

| 顺序 | 文件 | 主要片段 |
| --- | --- | --- |
| 1 | [`01_trigger_m0_ascending_write0.png`](ila_waveforms/01_trigger_m0_ascending_write0.png) | `start_pulse` 与 M0 递增写 0 |
| 2 | [`02_m1_ascending_read0_write1.png`](ila_waveforms/02_m1_ascending_read0_write1.png) | M1 递增读 0、写 1 |
| 3 | [`03_m1_to_m2_transition.png`](ila_waveforms/03_m1_to_m2_transition.png) | M1 末端到 M2 起点 |
| 4 | [`04_m2_to_m3_direction_reversal.png`](ila_waveforms/04_m2_to_m3_direction_reversal.png) | M2 末端到 M3 递减起点 |
| 5 | [`05_m3_to_m4_transition.png`](ila_waveforms/05_m3_to_m4_transition.png) | M3 末端到 M4 起点 |
| 6 | [`06_m4_to_m5_final_read.png`](ila_waveforms/06_m4_to_m5_final_read.png) | M4 末端到 M5 递增读 |
| 7 | [`07_m5_done_pass_640_requests.png`](ila_waveforms/07_m5_done_pass_640_requests.png) | M5 最后读响应、640 请求、DONE/PASS |

截图左侧 `Value` 是光标所在采样点的值，可能不是截图右侧波形所展示的时间；最终结论以原始采样数据及截图时间轴上的信号为准。

## 原始数据与复核

- Vivado 原生 ILA 文件：`ila_capture/2026-09-26_march_c_minus_64x8_full_run.ila`。原文件名为 `ILADATA.ila`，内含探针、波形 CSV/VCD/WDB 和窗口配置。
- [完整波形 CSV](ila_capture/full_run_waveform.csv) 与 [VCD](ila_capture/full_run_waveform.vcd)：从原生 `.ila` 无损提取的 1024 个采样；若需在 Vivado 中重开，应使用原生 `.ila`。
- [审计结果 JSON](ila_audit.json)：每笔请求对照 [`v1 冻结序列`](../../../specs/march_c_minus_64x8.csv) 的阶段、地址、操作、写数据及读响应；也检查一拍响应、计数、完成时机和最终状态。

在项目根目录复核：

```powershell
py -3 scripts/audit_step08_ila.py
```

预期输出：`STEP08_HARDWARE_ILA_AUDIT_PASS samples=1024 requests=640 reads=320 writes=320 done_sample=961 pass=1 fail=0`。

本证据只覆盖一次无故障 64×8 BRAM 正常运行。板级受控 FAIL 路径和真实存储器物理故障覆盖率不在本次结论范围内。

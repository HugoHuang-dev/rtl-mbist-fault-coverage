# v8 板级包装层仿真

本目录保存 XSim 与 Icarus 对板级包装层的仿真日志和检查结果。测试范围、工具命令与完整系统资源时序见[FPGA 实现报告](../../../docs/08_fpga_implementation.md)。

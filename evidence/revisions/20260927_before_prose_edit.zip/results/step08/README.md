# v8～v9 FPGA 实现与板级证据

正常/扰动的 LED、ILA 四种配置完成 50 MHz 实现和板级测试。五份原生 ILA 均完整执行 640 笔请求，正常三轮 PASS，扰动两轮 FAIL。

| 入口 | 内容 |
| --- | --- |
| [最终构建报告](../reruns/20260926_review_final/README.md) | 四种配置的 Utilization、Timing Summary、CDC、同步链检查和仿真 |
| [板级实测](hardware_final/README.md) | 器件识别、复位、重复启动、正常/扰动 LED、五份 ILA 与审计 |
| [位流及探针](../../releases/20260926_review/README.md) | 六个发布文件及 SHA-256 |
| [实现说明](../../docs/08_fpga_implementation.md) | BRAM 映射、读时序、资源、时序和硬件结果 |
| [上板手册](../../docs/08_board_bringup_steps.md) | 下载与采集流程 |
| [复现命令](../../docs/reproduce.md) | 仿真、构建、结果审计 |
| [独立控制器资源](controller/utilization.rpt) | 48 LUT、40 FF、0 BRAM |

## 初始构建归档

本目录 `base/`、`ila/`、`simulation/` 保存初始正常版本的实现与仿真；`summary.json`、`source_sha256.txt` 记录相应审计和指纹。[初始板级采集](hardware/README.md)保存正常运行的原始照片、阶段截图、ILA 和逐笔核对。当前下载文件及验收结果从上表进入。

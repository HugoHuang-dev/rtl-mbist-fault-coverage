# v9 板级实测与终版验收

达芬奇 XC7A35TFGG484-2I，Vivado 2018.3，50 MHz，64×8 bit 片上 BRAM。正常和受控读响应扰动配置均完成板级测试。采集截图时间为 2026-09-26，资料于 2026-09-27 汇总。

## 验收结果

| 测试 | 结果 | 证据 |
| --- | --- | --- |
| 器件识别与下载 | xc7a35t，Programmed | [Hardware Manager](screenshots/01_hardware_manager_programmed.png) |
| 正常 LED 运行 | DONE/PASS 亮，FAIL/BUSY 灭 | [首次运行](photos/04_normal_first_pass.jpg) |
| 复位清除结果 | RESET 后四个结果灯全灭 | [复位状态](photos/03_normal_after_reset.jpg)、[完成后复位](photos/05_normal_reset_clears_result.jpg) |
| 复位后重启 | 正常完成，返回 PASS | [灯态](photos/06_normal_pass_after_reset.jpg)、[原生 ILA](captures/11_normal_ila_after_reset.ila) |
| 正常连续启动 | 两轮均完成 640 请求并 PASS | [第一轮](captures/08_normal_ila_round1.ila)、[第二轮](captures/10_normal_ila_round2.ila) |
| 扰动 LED 运行 | DONE/FAIL 亮，PASS/BUSY 灭 | [LED 配置](photos/12_fault_led_done_fail.jpg)、[ILA 配置](photos/17_fault_ila_board_leds.jpg) |
| 扰动诊断与连续启动 | 两轮均完整执行，错误数 1，首错 M2/地址 7/FF→FE | [首错截图](screenshots/13_fault_ila_first_error.png)、[第一轮](captures/15_fault_ila_round1.ila)、[第二轮](captures/16_fault_ila_round2.ila) |

## 原生 ILA 核对

[`audit_final_hardware.py`](../../../scripts/audit_final_hardware.py)读取五份原生采集，与 v1 冻结序列逐笔比较。每份均有 1024 个样点、640 笔请求（320 读、320 写），M0～M5 分别为 64/128/128/128/128/64 笔。每笔读请求在下一样点出现有效响应。最后请求、响应、DONE 分别位于样点 959、960、961。

正常的三轮均返回 PASS、错误数 0。扰动的两轮在样点 279 观察到 FF→FE，样点 280 锁存 FAIL 及首次诊断，随后继续运行至 DONE；错误数最终为 1。第二轮的样点 0 保留上一轮结果，样点 1 开始清零计数和诊断，新的测试独立完成。

| 原生文件 | 模式 | 请求数 | DONE 样点 | PASS | FAIL | 错误数 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 08_normal_ila_round1.ila | 正常第一轮 | 640 | 961 | 1 | 0 | 0 |
| 10_normal_ila_round2.ila | 正常第二轮 | 640 | 961 | 1 | 0 | 0 |
| 11_normal_ila_after_reset.ila | 正常复位后重启 | 640 | 961 | 1 | 0 | 0 |
| 15_fault_ila_round1.ila | 扰动第一轮 | 640 | 961 | 0 | 1 | 1 |
| 16_fault_ila_round2.ila | 扰动第二轮 | 640 | 961 | 0 | 1 | 1 |

[完整审计 JSON](audit.json)、[汇总 CSV](capture_summary.csv)、[审计器负面检查](audit_self_check.json)。`exports/` 中保存从原生采集逐字节提取的 CSV/VCD。采集内的核 UUID、18 组探针端口、宽度和信号名与对应发布 LTX 一致；发布位流与实现目录位流逐字节一致。

## 资源与时序

[最终实现报告](../../reruns/20260926_review_final/README.md)保存正常/扰动的 LED、ILA 四种构建。四者均满足 20 ns 约束，WNS 分别为 +14.474、+13.458、+15.085、+13.031 ns，TNS/THS 为 0。[实现与硬件联合审计](../../reruns/20260926_review_final/step08/revision_audit.json)通过。[下载文件](../../../releases/20260926_review/README.md)。

## 文件索引

所有照片、截图和原生 ILA 保留原文件内容与命名。

| 文件 | 内容 |
| --- | --- |
| [01_hardware_manager_programmed.png](screenshots/01_hardware_manager_programmed.png) | Hardware Manager：XC7A35T，Programmed，正常 LED 位流 |
| [02_board_connections.jpg](photos/02_board_connections.jpg) | 板卡芯片、供电与 JTAG 连接 |
| [03_normal_after_reset.jpg](photos/03_normal_after_reset.jpg) | 正常配置复位后：LED0～3 全灭 |
| [04_normal_first_pass.jpg](photos/04_normal_first_pass.jpg) | 正常首次启动：DONE/PASS 亮 |
| [05_normal_reset_clears_result.jpg](photos/05_normal_reset_clears_result.jpg) | 正常完成后按 RESET：结果灯清零 |
| [06_normal_pass_after_reset.jpg](photos/06_normal_pass_after_reset.jpg) | 复位后重新启动：DONE/PASS 亮 |
| [07_normal_ila_round1_done.png](screenshots/07_normal_ila_round1_done.png) | 正常 ILA 第一轮完成状态 |
| [08_normal_ila_round1.ila](captures/08_normal_ila_round1.ila) | 正常 ILA 第一轮原生采集 |
| [09_normal_ila_round2_done.png](screenshots/09_normal_ila_round2_done.png) | 正常 ILA 第二轮完成状态 |
| [10_normal_ila_round2.ila](captures/10_normal_ila_round2.ila) | 正常 ILA 第二轮原生采集（不复位重启） |
| [11_normal_ila_after_reset.ila](captures/11_normal_ila_after_reset.ila) | 正常 ILA 复位后重新启动的原生采集 |
| [12_fault_led_done_fail.jpg](photos/12_fault_led_done_fail.jpg) | 扰动 LED 配置：DONE/FAIL 亮 |
| [13_fault_ila_first_error.png](screenshots/13_fault_ila_first_error.png) | 扰动首次诊断：M2、地址 7、FF→FE |
| [14_fault_ila_done_640.png](screenshots/14_fault_ila_done_640.png) | 扰动运行完成：640 请求、DONE/FAIL、错误数 1 |
| [15_fault_ila_round1.ila](captures/15_fault_ila_round1.ila) | 扰动 ILA 第一轮原生采集 |
| [16_fault_ila_round2.ila](captures/16_fault_ila_round2.ila) | 扰动 ILA 第二轮原生采集（不复位重启） |
| [17_fault_ila_board_leds.jpg](photos/17_fault_ila_board_leds.jpg) | 扰动 ILA 配置：DONE/FAIL 亮 |

[原始文件清单](file_manifest.json)记录 17 个文件的 SHA-256；[归档校验清单](SHA256.txt)包含提取结果与报告。复核命令在工程根目录执行：

```powershell
py -3 scripts/audit_final_hardware.py --self-test
$env:MBIST_RUN_ID = '20260926_review_final'
py -3 scripts/audit_board_revision.py
```

受控异常由板级包装逻辑翻转一次读响应 bit 0，用于验证 FAIL 与诊断路径，不改变 BRAM 单元内容。板级复位证据覆盖结果清零和复位后重启；运行中复位与忙时启动由板级仿真验证。四类存储单元故障的覆盖率见 v7 仿真实验。

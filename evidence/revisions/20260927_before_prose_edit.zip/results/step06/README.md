# v6 可审计实验记录

**v6 · 09.18–09.21**。本目录保存 2,048 个故障实例的清单、双工具结果、原始日志和审计记录。

在项目根目录运行（Windows PowerShell）：

```powershell
$env:MBIST_RUN_ID = 'fault_check_01'
py -3 scripts/run_step06.py --mode all
$env:MBIST_AUDIT_RUN_ID = $env:MBIST_RUN_ID
py -3 scripts/audit_step06.py
py -3 scripts/run_step06.py --mode replay --fault-id F1023 --tool both
```

`--mode all` 顺序执行 32 个试运行实例及完整 2,048 个实例，分别以 XSim 2018.3 和 Icarus Verilog 执行。可以用 `--mode pilot` 或 `--mode full` 单独运行；`--chunk-size` 默认 64。运行器编译各工具一次，故障实例通过 `campaign.hex`、`selection.hex` 和 Testbench 配置，无需修改 RTL。`replay` 可换成 `F0000`～`F2047` 任一编号，且与已有全量记录逐字段比对。

| 文件或目录 | 内容 |
| --- | --- |
| `fault_manifest.csv` | 2,048 个目标实例，唯一编号、类型、地址、位 |
| `pilot_manifest.csv` | 32 个不同地址和数据位的试运行实例 |
| `campaign.hex`、`oracle.hex` | 仿真配置及由 v1 规格生成的独立事务参考 |
| `pilot/`、`full/` | 每工具每实例 CSV、JSONL，工具间 `consistency.csv` 和 `summary.json` |
| `raw/pilot/`、`raw/full/` | 按工具及批次保留原始仿真日志；每条 CSV 的 `raw_log` 指向相应批次 |
| `build/` | Icarus 编译以及 XSim 编译、展开日志 |
| `source_sha256.txt` | 规格、清单、脚本、RTL、验证源文件指纹 |
| `audit.json` | 清单、结构化记录、日志哈希及工具配对复查结果 |
| `replay/F1023/`、`raw/replay/F1023/` | 示例单实例复现结果及原始日志 |

`raw_results.csv` 和 `raw_results.jsonl` 的每一行都含 `fault_id`、`fault_type`、`fault_addr`、`fault_bit`、`activated`、`detected`、`first_fail_addr`、`first_fail_stage`、`request_count`、`simulation_status`，并补充激活/错误次数、首次期望与实际值、周期、结果分类、失败原因、尝试次数及日志 SHA-256。`simulation_status=invalid` 的记录保留 `reason`；`not_activated` 与 `activated_escape` 分别代表有效运行但故障未激活和有效运行中激活后未检出。两者不会混为一类，也不会静默移出清单。`detected_without_activation` 是无效记录。

实验结果：试运行 64 条和全量 4,096 条记录均有效；全量 2,048 对工具结果逐字段一致，4,096 条均为 `activated_detected`，每条请求数 640。`summary.json` 保存数量，覆盖率另由 v7 评估。运行日志按批次共享，因此多个实例可引用同一日志和哈希；按 `CASE_BEGIN id=` 与 `CASE_RESULT id=` 定位实例。

当前脚本将新结果写入 `results/reruns/<编号>/step06/`，本目录保留原实验。工具配置见[复现说明](../../docs/reproduce.md)。

# v3 原始证据与复现命令

**v3 · 09.07–09.10**。本目录保存控制器集成仿真日志和请求轨迹检查结果。

在项目根目录运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\sim\run_step03.ps1
```

脚本使用 Vivado/XSim 2018.3、Icarus Verilog 和 `py -3` 调用 Python。Vivado 与 Icarus 安装位置在脚本开头配置。XSim 与 Icarus 分别在 `sim/.build-step03-xsim` 和 `sim/.build-step03-iverilog` 编译运行。脚本保存下列实验记录并对每份运行日志执行独立 CSV 逐笔检查：

| 文件 | 内容 |
| --- | --- |
| `xsim_compile.log`、`xsim_elaborate.log`、`xsim_run.log` | XSim 编译、展开、两轮仿真及每笔请求轨迹 |
| `icarus_compile.log`、`icarus_run.log` | Icarus 编译、两轮仿真及每笔请求轨迹 |
| `xsim_trace_check.log`、`icarus_trace_check.log` | 与 v1 冻结 CSV 的独立逐笔比较结果 |
| `source_sha256.txt` | 此次验收的 RTL、Testbench、脚本及参考 CSV 的 SHA-256 指纹 |

两份仿真日志均有 `MBIST_TB_PASS normal_and_injected_continue`。无故障轮：640 笔、320 读/320 写、961 周期、PASS。单次读响应扰动轮：同样完成 640 笔，FAIL、1 次错误，首错 M2 地址 7。两份轨迹检查均有 `TRACE_CHECK_PASS`，共核对每份日志 1280 笔请求（两轮各 640 笔）。这里的周期数由 Testbench 从启动请求边沿起计数，不作为无额外空闲拍的性能承诺。

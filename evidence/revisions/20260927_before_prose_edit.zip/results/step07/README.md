# v7 覆盖率评估产物

**v7 · 09.22–09.23**。本目录保存覆盖率统计、首次检测阶段矩阵和逐实例评估结果。

在项目根目录运行：

```powershell
py -3 scripts/evaluate_fault_coverage.py
```

脚本只读取 v6 冻结清单、全量逐实例 CSV、64 份原始批次日志、源码指纹、审计记录和 v1 参考序列，不启动仿真器，也不修改 RTL。

| 文件 | 内容 |
| --- | --- |
| `fault_evaluation.csv` | 每个唯一 `fault_id` 一行；含确认检出与异常分类、首次检测阶段和两工具原始日志路径 |
| `coverage_by_type.csv` | 四类及总计的目标分母、确认检出、未激活、激活未检出、仿真无效/失败、工具分歧及覆盖率 |
| `detection_stage_matrix.csv` | 故障类型 × M0～M5 首次检测数量 |
| `exceptions.csv` | 未获得双工具一致确认检出的实例；本轮仅表头 |
| `efficiency.json` | 理论操作数、实测请求/周期及周期计数定义 |
| `summary.json` | 审计与核心统计的机器可读汇总 |
| `source_sha256.txt` | 分析脚本及关键输入证据的 SHA-256 |
| `evaluation.log` | 最终独立评估运行的通过标记与数量 |

完整方法、结果解释及适用范围见 [`../../docs/07_fault_coverage_evaluation.md`](../../docs/07_fault_coverage_evaluation.md)。本轮为 2,048 个唯一实例、4,096 条工具记录；确认检出 2,048，未激活、激活未检出、仿真无效、工具分歧均为 0。分母不将两种仿真器重复计算。

# 2026-09-26 最终板级构建

正常/扰动双工具仿真通过，四套位流满足 50 MHz 建立/保持时序。正常与扰动配置均完成板级测试，[照片与五轮 ILA](../../step08/hardware_final/README.md)已归档，联合审计通过。

| 构建 | 资源 | 时序 | CDC |
| --- | --- | --- | --- |
| 正常 LED | [资源](step08/base/implemented_utilization.rpt) | [时序](step08/base/implemented_timing_summary.rpt) | [CDC](step08/base/cdc.rpt) |
| 正常 ILA | [资源](step08/ila/utilization.rpt) | [时序](step08/ila/timing_summary.rpt) | [CDC](step08/ila/cdc.rpt) |
| 扰动 LED | [资源](step08/base_fault/implemented_utilization.rpt) | [时序](step08/base_fault/implemented_timing_summary.rpt) | [CDC](step08/base_fault/cdc.rpt) |
| 扰动 ILA | [资源](step08/ila_fault/utilization.rpt) | [时序](step08/ila_fault/timing_summary.rpt) | [CDC](step08/ila_fault/cdc.rpt) |

[板级仿真](step08/simulation/summary.json)、[实现审计](step08/revision_audit.json)、[对应源码 SHA256](source_sha256.txt)、[位流与探针](../../../releases/20260926_review/README.md)。构建命令和版本保存在 `step08/build_logs_normal/` 与 `build_logs_fault/`。

# 原始 ILA 的可迁移副本

`march_c_minus_64x8_portable.ila` 仅将内部 WCFG 的 WDB 引用改为同目录文件名。原文件保留在 `results/step08/hardware/ila_capture/`。

[转换校验](conversion.json)记录原文件与副本 SHA256，并逐项核对 ZIP 成员。WDB、CSV、VCD、LTX 和 DMP 的字节完全相同，仅 WCFG 路径变化。副本已由 Vivado 2018.3 的 `read_hw_ila_data` 成功导入；独立 WDB/WCFG 也可打开，过程见[日志](reopen.log)。

独立仿真波形查看器对 `u_mbist/phase` 发出对象名解析提示；该提示不表示原始采样丢失。完整阶段核对使用原生 ILA/CSV。离线批处理再次导出 CSV 不可用，原文件也有同样行为，因此 CSV 完整性以归档成员字节校验为准。

复现：设置 `MBIST_RUN_ID`，运行 `py -3 scripts/prepare_portable_ila.py`，再用 Vivado 2018.3 执行 `fpga/verify_portable_ila.tcl`。新的副本写入该编号的 `portable_ila/` 目录。

# 2026-09-26 软件复核

当前目录保存独立重跑的数据，原 `results/step02`～`step08` 保留。

| 内容 | 结果入口 |
| --- | --- |
| RAM 单元检查 | [Icarus](step02/icarus_check.txt)、[XSim](step02/xsim_check.txt) |
| 控制器集成轨迹 | [Icarus](step03/icarus_check.txt)、[XSim](step03/xsim_check.txt) |
| 14 项独立 Checker 回归 | [报告](step04/report.json) |
| 28 次故障定向测试 | [报告](step05/report.csv) |
| 全量 2048 实例 | [原始记录](step06/full/raw_results.csv)、[审计](step06/audit.json) |
| 独立覆盖率评估 | [汇总](step07/summary.json)、[阶段矩阵](step07/detection_stage_matrix.csv) |
| 单例 F0123 重放 | [记录](step06/replay/F0123/raw_results.csv) |
| ILA 可迁移副本 | [说明](portable_ila/README.md) |

`step08/` 保存修订过程中的初次构建及诊断日志，最终板级实现采用[review_final](../20260926_review_final/README.md)，不使用初次构建位流。[复核报告](../../../docs/09_engineering_review.md)记录最终结果。

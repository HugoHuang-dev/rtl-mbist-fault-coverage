# v5 定向仿真证据

**v5 · 09.14–09.17**。本目录保存故障 RAM 的单元测试与集成测试记录。

从项目根目录运行：

```powershell
py -3 .\scripts\run_step05.py
```

脚本使用 Vivado XSim 2018.3 与 Icarus Verilog。每个配置在独立仿真进程中运行；编译文件和中间产物保存在临时工作目录。XSim 2018.3 的 Windows 批处理包装器要求 `-testplusarg` 的 `NAME=VALUE` 参数加内层引号，脚本已处理。

| 文件 | 内容 |
| --- | --- |
| `report.csv` | 每个工具、单元/集成测试、配置、激活、检测、首错诊断和 PASS/FAIL；共 28 行结果 |
| `oracle.hex` | 根据 v1 冻结 CSV 生成的事务表，供 v4 独立 Checker 使用 |
| `{tool}_{suite}_compile.log` | Icarus 或 XSim 对单元/集成测试的独立编译日志 |
| `xsim_{suite}_elaborate.log` | XSim 展开日志 |
| `{tool}_{suite}_{case}.log` | 每个配置的独立仿真原始日志，含激活事件、检查器结果及最终诊断 |
| `source_sha256.txt` | 故障模型、参考监控器、测试脚本、原 MBIST RTL 和冻结规格的源码指纹 |

验收规则：`report.csv` 的 28 行均须 `status=PASS`，7 组集成案例的 XSim/Icarus 激活、检测、首错字段逐项一致。无故障必须 `detected=0`；其余定向案例必须 `activated=1` 且 `detected=1`。脚本遇到编译、运行、检查器、参考模型或两工具结果差异时写入 `FAIL` 并返回非零码。本目录不含覆盖率百分比。

# v4 回归证据

**v4 · 09.11–09.13**。本目录保存独立检查器的基线与负面回归结果。

在项目根目录运行：

```powershell
py -3 .\scripts\run_step04.py
```

脚本使用 XSim/Vivado 2018.3 与 Icarus Verilog，将单点 RTL 变体写入临时工作目录，不修改正式 RTL。临时目录内含各案例的生成源码、`oracle.hex` 和仿真构建文件；本目录保存可复查的输入、日志及报告。

| 文件 | 说明 |
| --- | --- |
| `oracle.hex` | 从冻结 CSV 逐行生成的 18 位期望事务表 |
| `report.csv`、`report.json` | 14 个案例的仿真器、变体、预期拒绝类别和回归结果 |
| `{engine}_{variant}_compile.log` | 每个案例的独立编译日志 |
| `xsim_{variant}_elaborate.log` | XSim 展开日志 |
| `{engine}_{variant}_run.log` | 独立检查器运行日志；正常案例含两个 `CHECKER_PASS`，错误案例含对应 `CHECKER_FAIL code` 和 fatal |
| `source_sha256.txt` | 冻结 CSV、生成的事务表、检查器、回归脚本及正式 RTL 的源码指纹 |

验收：`report.csv` 有 14 行结果，2 个 `baseline` 的 `dut_outcome=accepted`，其余 12 行 `dut_outcome=rejected`，所有行 `regression_status=PASS`。脚本即使遇到失败案例也会把它写成 `regression_status=FAIL` 并以非零码退出。仿真进程退出码单独保存在 `sim_exit`，不用于把预期负面案例误记为 DUT 通过。错误类别与每个日志中的 `CHECKER_FAIL` 编号一一对应。

# 首次上板工程的生成文件

此目录保留首次构建的 `.xpr`、运行报告和缓存；原位流与硬件证据见[首次上板文件](../../releases/README.md)。原版本源码可在[源码快照索引](../../evidence/README.md)中找到。

当前源码已经修订，不应把此目录的旧缓存与当前源码视为同一次构建。当前工程请按[复现说明](../../docs/reproduce.md)重新生成；输出位于 `.build/<编号>/vivado` 或 `vivado_fault`，对应结果见[修订报告](../../docs/09_engineering_review.md)。

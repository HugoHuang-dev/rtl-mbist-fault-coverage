# FPGA 工程

[board_top.v](board_top.v) 连接 50 MHz 时钟、复位同步链、KEY0 去抖、LED、MBIST 和 BRAM。[board_pins.xdc](board_pins.xdc) 定义管脚及时序例外。

当前构建使用 [run_board_build.py](../scripts/run_board_build.py)，输出到项目内 `.build/<编号>/vivado` 或 `vivado_fault`。参数、报告和校验方式见[复现说明](../docs/reproduce.md)。

[修订报告](../docs/09_engineering_review.md)列出正常及受控扰动构建；[首次上板工程](vivado/README.md)保留原验证记录。

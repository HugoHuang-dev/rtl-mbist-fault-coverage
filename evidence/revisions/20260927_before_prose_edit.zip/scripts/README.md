# 自动化与审计脚本

| 版本 | 入口 | 功能 |
| --- | --- | --- |
| v1 | [`generate_march_reference.py`](generate_march_reference.py) | 生成 640 笔参考序列 |
| v4 | [`run_step04.py`](run_step04.py) | 独立检查器负面回归 |
| v5 | [`run_step05.py`](run_step05.py) | 故障 RAM 定向测试 |
| v6 | [`generate_fault_manifest.py`](generate_fault_manifest.py)、[`run_step06.py`](run_step06.py)、[`audit_step06.py`](audit_step06.py) | 清单、批量运行及原始记录审计 |
| v7 | [`evaluate_fault_coverage.py`](evaluate_fault_coverage.py) | 覆盖率和首次检测阶段评估 |
| v8～v9 | [`audit_step08.py`](audit_step08.py)、[`audit_step08_ila.py`](audit_step08_ila.py) | 实现报告与 ILA 数据审计 |

从工程根目录运行；命令和输入文件见各版本的[结果索引](../README.md)。

当前环境配置和运行目录见[复现说明](../docs/reproduce.md)。新增入口：[基础仿真](run_basic_sim.py)、[板级构建](run_board_build.py)、[修订审计](audit_board_revision.py)。

终版板级采集审计：[audit_final_hardware.py](audit_final_hardware.py)，读取五份原生 ILA，核对事务、响应、诊断、重启与完成状态；结果见[板级验收](../results/step08/hardware_final/README.md)。

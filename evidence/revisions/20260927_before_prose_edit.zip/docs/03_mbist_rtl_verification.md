# v3：March C− 控制器 RTL 与集成验收

**v3 · 09.07–09.10**。控制器连接无故障 RAM 后完成 March C− 全序列测试，记录 PASS 和 640 笔请求。命令、轨迹及日志见[v3 证据](../results/step03/README.md)。

## 实现结构

| 模块 | 职责 |
| --- | --- |
| `march_controller.v` | IDLE、请求、等待读响应、读后写、DONE 状态；M0～M5 切换和地址边界 |
| `address_generator.v` | 按阶段加载起始地址，逐地址递增或递减 |
| `data_generator.v` | 分别产生写数据和读期望 `00/FF` |
| `memory_interface.v` | 将状态机请求接入已冻结的 RAM request/response 接口，按 `req_ready` 确认接受 |
| `response_checker.v` | 仅在等待状态且 `rd_valid` 有效时比较；保持首错信息与错误次数 |
| `mbist_top.v` | 连接以上模块，对外提供 RAM 接口、BUSY/DONE/PASS/FAIL 和诊断字段 |

参考 R1 的模块划分，RTL、握手和时序按本项目接口实现。比较错误后继续测试至完成，因此未采用 R1 的提前结束路径。控制器最多保留一笔未完成读；读请求在 `E_k` 接受，`rd_valid/rd_data` 在沿后更新，控制器于 `E_{k+1}` 采样比较。M5 地址 63 的读比较完成后进入 DONE。`pass = done && !fail`，末笔读出错也不会误报 PASS。

v4 的事务 Checker 根据外部请求和冻结 CSV 判断阶段，不依赖控制器内部 FSM。

## 验收证据

复现入口及原始日志在 [`../results/step03/README.md`](../results/step03/README.md)。XSim 2018.3 和 Icarus Verilog 11.0 各自编译、运行同一 RTL/Testbench，均以退出码 0 结束。每个工具完成两轮：

| 场景 | 请求 | 读 / 写 | 周期 | 结果 |
| --- | ---: | ---: | ---: | --- |
| 无故障 RAM | 640 | 320 / 320 | 961 | DONE=1，PASS=1，FAIL=0，错误数 0 |
| 单次读响应扰动 | 640 | 320 / 320 | 961 | DONE=1，PASS=0，FAIL=1，错误数 1；首错 M2 / 地址 7 / 期望 FF / 实际 FE |

本版 Testbench 为白盒集成测试：读取 `dut.u_controller.phase` 核对阶段，并检查地址、读写类型和写数据；Python 再将两份仿真轨迹与 v1 冻结的 [`../specs/march_c_minus_64x8.csv`](../specs/march_c_minus_64x8.csv) 的 640 行逐项比对，两份检查均通过。运行中额外 `start` 脉冲未重新启动，DONE 结果保持，且从 DONE 可接受下一次启动。第二轮的单次扰动验证比较与继续执行路径；故障 RAM 和覆盖率数据分别见 v5～v7。

## 范围

v3 的验收针对无故障 RAM 上的完整 March C− 请求序列和控制器诊断。独立事务检查、故障实验、综合及时序、板级实测分别见 v4～v9 的记录。当前 RAM 使用 v2 验证的一拍同步读接口。

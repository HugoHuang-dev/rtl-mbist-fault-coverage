# v2 最终验收：单端口同步 RAM

**v2 · 09.04–09.06**。单端口同步 RAM 通过独立 Testbench；Vivado 综合确认 RAMB18E1 映射。命令和日志见[v2 证据](../results/step02/README.md)。

## 对象与工具

- RTL：[`rtl/single_port_sync_ram.v`](../rtl/single_port_sync_ram.v)。默认 64×8、6 位地址、50 MHz 单时钟；`ram_style="block"` 要求 Vivado 优先映射 Block RAM。
- 独立 Testbench：[`tb/tb_single_port_sync_ram.sv`](../tb/tb_single_port_sync_ram.sv)。shadow RAM 只根据已接受的写请求维护期望数据；不读取 DUT 内部数组，也不实例化 MBIST 控制器。
- 主仿真：Vivado XSim 2018.3。交叉验证：Icarus Verilog 11.0。两者在独立构建目录从相同源码分别编译运行。
- RAM-only 综合：Vivado 2018.3。板卡规格书丝印 `XC7A35TFGG484-2I`；7 系列 Vivado 以 `xc7a35tfgg484-2` 选择器件/封装/速度级，在打开综合设计后以 `set_operating_conditions -grade Industrial` 指定工业温度级。温度级用于后续操作条件分析，RAM 映射由目标器件/封装/速度级确定。[AMD UG899](https://docs.amd.com/api/khub/documents/kobHePaH8nZX6Ubq4SnCaQ/content)给出 7 系列温度级的独立设置方法。

## 接口与一拍读时序复核

正常运行时 `req_ready=1`；复位期间为 0。`req_valid && req_ready` 在上升沿 `E_k` 接受一笔请求。写请求在 `E_k` 更新 RAM，且不产生 `rd_valid`。读请求在 `E_k` 使 `rd_data/rd_valid` 通过非阻塞赋值于该沿后更新；另一个同步模块在 `E_{k+1}` 的触发区读取到这笔响应。写拍、空闲拍和复位拍均不会产生新读响应；`rd_data` 保持最近的读值。RAM 内容既不初始化也不随 `rst_n` 清零。

Testbench 从三个不同仿真时刻检查这份契约：

1. **负沿驱动后、下一正沿前**：改变地址/请求并等待 1 ns，检查 `rd_data/rd_valid` 没有提前变化，排除异步读误判。
2. **请求接受沿 `E_k` 后 1 ns**：等待 DUT 的非阻塞赋值完成，检查本拍读请求对应的 `rd_valid` 和 shadow RAM 数据；写/空闲/复位拍检查无伪响应。
3. **下一正沿 `E_{k+1}` 的触发区、NBA 更新前**：再检查上一拍的 `rd_valid/rd_data`，模拟真实同步控制器采样输入。刺激只在负沿改变，因此正沿检查没有 Testbench 驱动竞争。

这三项同时通过，因此一拍延迟的结论不依赖单独的 `#1` 观察点。对连续读，`rd_valid` 可以连续保持高，但每拍数据必须对应各自地址；Testbench 逐拍核对。

Vivado 综合日志显示 **1 个 `RAMB18E1`，`DOA_REG=0`，`WRITE_MODE_A=NO_CHANGE`**。`DOA_REG=0` 表示未启用 Block RAM 可选输出寄存器；[AMD 7 系列 UG473](https://docs.amd.com/v/u/en-US/ug473_7Series_Memory_Resources)说明读数据在读时钟沿后稳定，额外输出寄存器会增加一拍。当前原语配置与 RTL 的沿后输出、下一沿消费时序及 Testbench 检查一致。`WRITE_MODE_A=NO_CHANGE` 与写拍不更新 `rd_data` 的 RTL 一致。

## 功能场景与结果

| 场景 | 验证内容 | XSim | Icarus |
| --- | --- | --- | --- |
| 地址边界与稀疏访问 | 地址 0、63 写入不同数据后读取；检查不会混淆 | 通过 | 通过 |
| 连续写、连续读 | 64 个地址逐拍写不同数据，再逐拍读回；shadow RAM 逐项比对 | 通过 | 通过 |
| 交替读写 | 写后下一拍读同地址；从地址 63 切到 0 | 通过 | 通过 |
| 空闲和写拍输出 | `rd_valid=0`，`rd_data` 保持；无伪响应 | 通过 | 通过 |
| 同步读时序 | 负沿改地址不提前变化，`E_k` 后有效，`E_{k+1}` 可被同步模块采样 | 通过 | 通过 |
| 复位 | 清除响应有效、阻止复位沿写入、保留 RAM 内容；复位后读回 | 通过 | 通过 |
| 超时保护 | 测试无进展时触发失败 | 已配置 | 已配置 |

两套仿真均以退出码 0 完成，并输出四个 `CASE_PASS` 标记及 `RAM_TB_PASS checks=146 reads=70 writes=68`。综合脚本以退出码 0 完成，0 errors、0 critical warnings、0 warnings。详细原始证据及复现命令见 [`results/step02/README.md`](../results/step02/README.md)。

## v2 验证范围

- v2 的证据为 RTL 仿真及 RAM-only 结构综合。完整系统资源、时序及板级实测见 v8～v9 记录。
- 项目固定使用 Vivado 2018.3；v2 的 XSim 和 RAM-only 综合结果均来自该版本。
- 未在 v2 验证附加输出寄存器 `DOA_REG=1`、其他读延迟的 BRAM IP、门级反标时序、故障注入、未写地址的数据值或更复杂的复位/时钟异常。当前接口 6 位地址只能表达 `0..63`，不存在可输入的越界地址编码。
- 512 位 RAM 使用一个 RAMB18E1，资源利用率较低；统一接口保持一拍读响应。完整系统资源数见 v8 实现报告。

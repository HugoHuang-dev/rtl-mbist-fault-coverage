# v8～v9：FPGA 实现与板级验证

达芬奇 XC7A35TFGG484-2I，Vivado 2018.3，50 MHz。正常和受控扰动的 LED/ILA 四种配置完成综合、布局布线和板级测试。完整结果见[构建报告](../results/reruns/20260926_review_final/README.md)与[板级实测](../results/step08/hardware_final/README.md)。

## 板级接口与同步

复用 `mbist_top`，March C− 算法和 64×8 存储器规格保持一致。[`board_top.v`](../fpga/board_top.v)连接 RESET、KEY0、LED、片上 BRAM 及 ILA 请求计数。器件 part 为 `xc7a35tfgg484-2`，操作条件为 Industrial。

RESET 两级异步清零、同步释放，再经一级同步寄存器驱动核心。KEY0 经过两级同步和 500,000 拍去抖，按下约 10 ms 后产生启动脉冲。两条同步链标记 `ASYNC_REG`；外部按键仅排除到首级 D 的路径，外部复位仅排除同步链 CLR 端，级间路径继续进行时序分析。LED 是静态状态输出，没有外部采样时钟。约束见 [`board_pins.xdc`](../fpga/board_pins.xdc)。

| 接口 | 引脚 | 功能 |
| --- | --- | --- |
| sys_clk | R4 | 50 MHz 时钟 |
| sys_rst_n | U2 | 按下低有效 |
| key0 | T1 | 按下启动 |
| LED0～3 | R2/R3/V2/Y2 | DONE/PASS/FAIL/BUSY，高电平点亮 |

## 存储器与读时序

MUT 映射为一个 RAMB18E1，`DOA_REG=0`、`WRITE_MODE_A=NO_CHANGE`，见[BRAM 配置](../results/reruns/20260926_review_final/step08/base/bram_configuration.txt)。`DOA_REG=0` 表示不启用额外输出寄存级，仍然是同步读：请求在接受沿采样，读数据随后更新，控制器在下一上升沿使用有效响应。

原生 ILA 逐笔检查确认读响应相对请求晚一个采样点。末笔请求在 959，响应在 960，DONE 在 961。六阶段共 640 请求、320 读和 320 写。从触发到 DONE 为 961 个采样间隔；首笔请求到 DONE 为 960 个时钟间隔，50 MHz 下为 19.2 µs。

## 资源与时序

| 构建 | LUT | FF | RAMB18 / RAMB36 | WNS / ns | WHS / ns |
| --- | ---: | ---: | --- | ---: | ---: |
| 独立控制器综合 | 48 | 40 | 0 / 0 | 未布局布线 | 未布局布线 |
| 正常，无 ILA | 98 | 63 | 1 / 0 | +14.474 | +0.121 |
| 正常，带 ILA | 1930 | 2934 | 2 / 2 | +13.458 | +0.036 |
| 扰动，无 ILA | 112 | 73 | 1 / 0 | +15.085 | +0.130 |
| 扰动，带 ILA | 1941 | 2944 | 2 / 2 | +13.031 | +0.062 |

四个实现的 TNS/THS 为 0，均满足 20 ns 时钟约束。[报告索引](../results/reruns/20260926_review_final/README.md)包含各配置的 Utilization、Timing Summary 和 CDC 报告；关键路径保存在相应目录的 `critical_paths.rpt`。独立控制器资源见[综合报告](../results/step08/controller/utilization.rpt)。

无 ILA 配置的 CDC 无 Warning/Critical。ILA 配置有 156 条调试 IP 内部 CDC 警告路径，位于 `dbg_hub`；板级同步链只有 CDC-3/CDC-9 信息项。[同步链检查](../results/reruns/20260926_review_final/step08/base/synchronizer_checks.txt)确认三个级间路径仍参与时序分析。

## 正常与异常板级结果

- 正常无 ILA 配置：KEY0 后 LED0/LED1 亮；RESET 清除结果灯，复位后重新启动仍返回 PASS。
- 正常 ILA 配置：首次启动、连续第二次启动、复位后重启共三轮，均 PASS、错误数 0、640 请求。
- 扰动无 ILA 配置：KEY0 后 LED0/LED2 亮，表示 DONE/FAIL。
- 扰动 ILA 配置：连续两轮均 FAIL、错误数 1，首错 M2、地址 7、期望 FF、实际 FE，且完整执行 640 请求。

扰动只由板级包装模块翻转第 72 次读响应的 bit 0，不改控制器算法，也不修改 BRAM 单元。样点 279 出现 FE，280 锁存诊断，961 完成。第二轮样点 0 保留前次结果，样点 1 清除计数、FAIL 和首错，随后独立完成新一轮。

[17 份实测资料](../results/step08/hardware_final/README.md)保存照片、截图和五份原生 `.ila`。[硬件审计](../results/step08/hardware_final/audit.json)检查逐笔序列、一拍响应、完成时机、错误数、首次诊断及重启清零。采集内核 UUID 和探针映射与发布 LTX 一致。[位流](../releases/20260926_review/README.md)与实现输出逐字节一致。

## 验收

v8 综合与实现、v9 板级正常/受控异常测试均完成。板级复位证据覆盖完成后清零及重新启动；运行中复位和忙时启动由[双工具板级仿真](../results/reruns/20260926_review_final/step08/simulation/summary.json)检查。存储单元四类故障的覆盖率统计属于 v7 行为模型实验。

[复现命令](reproduce.md) · [操作手册](08_board_bringup_steps.md) · [工程复核记录](09_engineering_review.md)

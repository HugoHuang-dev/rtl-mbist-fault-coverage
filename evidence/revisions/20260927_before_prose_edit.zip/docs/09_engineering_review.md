# 工程复核与修订 · 2026-09-26

本次修订完善构建路径、同步约束和板级诊断验证。March C− 控制器及四类故障模型的逻辑保持一致。正常与扰动配置已完成板级运行、复位与重复启动验证。

## 板级改动

- RESET 使用两级异步清零、同步释放链，再经一级同步寄存器驱动核心，避免 BRAM 控制受异步复位直接影响。
- 复位同步链和 KEY0 同步链声明 `ASYNC_REG`。外部按键只对首级 D 端设置例外，外部复位只对同步链的两个 CLR 端设置例外；三个级间路径继续参与时序分析。
- LED 为静态状态指示，没有外部采样时钟。XDC 显式排除到 LED 端口的外部时序路径，不虚设输入/输出延迟。
- 请求计数仅在控制器接受启动时清零，忙时 KEY0 脉冲不再清零计数。
- `INJECT_READ_FAULT=0` 为正常默认配置。设为 1 时，板级包装模块对第 72 次读响应翻转 bit 0；不访问控制器内部阶段，也不修改 BRAM 内容。

初次补充 CDC 检查时，旧的复位首级异步、次级同步结构仍报告 CDC-7。本次增加完整同步释放链后，外部输入仅剩 CDC-3 和 CDC-9 信息项。受控扰动接口首次接线方向错误，由独立 Checker 在第一笔读响应处拒绝；修正后正常与扰动回归全部通过。

## 仿真与故障回归

| 检查 | 结果 | 证据 |
| --- | --- | --- |
| RAM 单元测试 | 每工具 146 项检查，70 读、68 写 | [Icarus](../results/reruns/20260926_engineering_review/step02/icarus_check.txt)、[XSim](../results/reruns/20260926_engineering_review/step02/xsim_check.txt) |
| v3 集成轨迹 | 每工具两轮、1280 笔请求通过 | [Icarus](../results/reruns/20260926_engineering_review/step03/icarus_check.txt)、[XSim](../results/reruns/20260926_engineering_review/step03/xsim_check.txt) |
| 独立 Checker | 14 项回归通过；12 次错误变体均被拒绝 | [报告](../results/reruns/20260926_engineering_review/step04/report.json) |
| 故障 RAM 定向测试 | 28 次通过 | [报告](../results/reruns/20260926_engineering_review/step05/report.csv) |
| 全量故障实验 | 2048 个实例、4096 条工具记录；无无效案例和工具分歧 | [原始结果](../results/reruns/20260926_engineering_review/step06/full/raw_results.csv)、[审计](../results/reruns/20260926_engineering_review/step06/audit.json) |
| 独立统计 | 2048 个唯一实例均激活并检出；首检阶段与原结果一致 | [统计](../results/reruns/20260926_engineering_review/step07/summary.json) |
| 单例重放 | F0123 双工具结果与全量记录一致 | [结果](../results/reruns/20260926_engineering_review/step06/replay/F0123/raw_results.csv) |
| 板级包装仿真 | 每工具正常/扰动各三轮；忙时启动、运行中复位及重启通过 | [结果](../results/reruns/20260926_review_final/step08/simulation/summary.json) |

扰动轮返回 `DONE=1, PASS=0, FAIL=1`，错误数 1，首错 M2 / 地址 7 / 期望 FF / 实际 FE，全部 640 笔请求仍然执行。正常轮返回 PASS。该表记录双工具仿真；板级照片和原生采集见下文。

迁移复核：将源码复制到含空格的新目录，双工具重新完成 32 实例试运行及正常/扰动板级仿真，输出均位于迁移后的工程内。[迁移结果](../results/reruns/20260926_engineering_review/relocation/summary.json)。

## 实现结果

器件 `xc7a35tfgg484-2`，Industrial，Vivado 2018.3，时钟周期 20 ns。四个构建的 TNS、THS 均为 0。

| 构建 | LUT | FF | RAMB18 / RAMB36 | WNS / ns | WHS / ns |
| --- | ---: | ---: | --- | ---: | ---: |
| 正常，无 ILA | 98 | 63 | 1 / 0 | +14.474 | +0.121 |
| 正常，带 ILA | 1930 | 2934 | 2 / 2 | +13.458 | +0.036 |
| 扰动，无 ILA | 112 | 73 | 1 / 0 | +15.085 | +0.130 |
| 扰动，带 ILA | 1941 | 2944 | 2 / 2 | +13.031 | +0.062 |

[正常时序](../results/reruns/20260926_review_final/step08/base/implemented_timing_summary.rpt)、[正常 ILA 时序](../results/reruns/20260926_review_final/step08/ila/timing_summary.rpt)、[扰动时序](../results/reruns/20260926_review_final/step08/base_fault/implemented_timing_summary.rpt)、[扰动 ILA 时序](../results/reruns/20260926_review_final/step08/ila_fault/timing_summary.rpt)。综合确认被测 RAM 仍为 RAMB18E1、DOA_REG=0。

[同步链检查](../results/reruns/20260926_review_final/step08/base/synchronizer_checks.txt)确认级间路径未被排除；[时序例外](../results/reruns/20260926_review_final/step08/base/exceptions.rpt)覆盖指定端点。无 ILA 版 CDC 无 Warning/Critical；ILA 版保留 156 条调试 IP 内部 CDC 警告路径，均位于 `dbg_hub`，没有额外放宽用户逻辑约束。[CDC 报告](../results/reruns/20260926_review_final/step08/ila/cdc.rpt)和[自动审计](../results/reruns/20260926_review_final/step08/revision_audit.json)保留具体分类。

## 构建与证据管理

仿真和实现使用项目内 `.build/<运行编号>/`，新结果写入 `results/reruns/<运行编号>/`。工具从环境变量、`toolchain.local.json` 或 PATH 发现；当前本机配置文件不纳入版本管理。命令见[复现说明](reproduce.md)。

原始 ILA 不变，另生成只调整 WCFG 数据库引用的[可迁移副本](../results/reruns/20260926_engineering_review/portable_ila/README.md)。WDB、CSV、VCD、LTX 和 DMP 均与原文件逐字节一致。

源码头保留作者、项目、文件和模块信息，删除无法逐文件核实的 Created/Revised 与 Editor。修改前源码与文档另存快照；当前源码校验见[SHA256 清单](../evidence/current_source_sha256.txt)。

## 板级验收

软件回归、全量故障实验、四套位流的建立/保持时序及板级验收完成。[17 份板级资料](../results/step08/hardware_final/README.md)包括器件识别、复位清零、正常/扰动灯态，以及正常三轮、扰动两轮原生 ILA。每轮 640 笔请求通过逐笔核对，正常返回 PASS，扰动返回 FAIL 并记录 M2/地址 7/FF→FE。两种模式的第二轮均正确清除上一轮状态。

# 设计、验证与开发记录

从[总 README](../README.md)的 v1～v9 演进表进入各版本文档。[开发日志](DEVLOG.md)记录设计、修正及验收；[上板操作手册](08_board_bringup_steps.md)记录板卡操作。

当前版本：[工程复核](09_engineering_review.md)、[复现说明](reproduce.md)。

终版硬件资料：[板级验收](../results/step08/hardware_final/README.md)、[资源与时序](../results/reruns/20260926_review_final/README.md)、[位流及探针](../releases/20260926_review/README.md)。

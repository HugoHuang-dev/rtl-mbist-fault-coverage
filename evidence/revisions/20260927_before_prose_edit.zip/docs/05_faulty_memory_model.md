# v5：单故障存储器模型与定向验收

**v5 · 09.14–09.17**。故障 RAM 完成单元测试及 MBIST 定向集成。配置、日志和结果见[v5 证据](../results/step05/README.md)。

## 配置与故障定义

仿真 RAM [`../tb/faulty_memory.sv`](../tb/faulty_memory.sv) 使用 `fault_type[2:0]`、`fault_addr[5:0]`、`fault_bit[2:0]` 配置**一个**故障实例；`fault_type=0` 为无故障，1/2/3/4 依次为 SA0、SA1、Rising TF、Falling TF。`fault_addr` 与 `fault_bit` 指向 64×8 RAM 的一个物理位。故障只改变存储单元的写入结果或该单元的读出位，不直接修改 MBIST 的 FAIL、诊断或结果端口。原有 `rtl/` 控制器保持不变。

| 类型 | 单元行为 | 激活事件 |
| --- | --- | --- |
| SA0 | 目标位读出及写后状态固定为 0 | 向目标位写 1 |
| SA1 | 目标位读出及写后状态固定为 1 | 向目标位写 0 |
| Rising TF | 已知旧值为 0 时，写 1 失败并保持 0 | 目标位发生真实的 `0→1` 写入尝试 |
| Falling TF | 已知旧值为 1 时，写 0 失败并保持 1 | 目标位发生真实的 `1→0` 写入尝试 |

转换故障在旧值未知或写入方向不符时**不计激活**。`fault_activated` 为本轮已发生过激活的保持标志；`activation_count` 统计激活**事件次数**，不是不同故障实例数。复位清除这两项和 `rd_valid`，保留 RAM 内容；测试脚本的每个案例用独立仿真进程开始，避免跨实例残留。模型拒绝非法或未知的 `fault_type`。

## 验证方法

1. [`../tb/tb_faulty_memory_unit.sv`](../tb/tb_faulty_memory_unit.sv) 不连接 MBIST，按预定写入/读回值与激活次数测试四种模型：目标位与相邻地址、相反方向写入、重复触发、同步读、复位阻止写入与内容保留。SA0/SA1 还在首次写入前检查目标读出位已被固定。
2. [`../tb/tb_step05_mbist.sv`](../tb/tb_step05_mbist.sv) 将故障 RAM 接入原 MBIST RTL。v4 的独立事务检查器继续验证 **640 笔请求完整执行**、读响应消费及首错诊断。新增 [`../tb/fault_reference_monitor.sv`](../tb/fault_reference_monitor.sv) 只依据外部 RAM 请求和自身参考单元状态推导实际应读出的数据、激活标志和次数；不读取故障 RAM 内部数组或控制器诊断。Testbench 另按物理故障与 March 序列预先给定首错阶段/地址及错误次数。
3. [`../scripts/run_step05.py`](../scripts/run_step05.py) 在 XSim 2018.3 和 Icarus 下分别执行无故障、四种目标地址 7/位 2 的故障，以及两个地址/位边界案例。每个案例是新的仿真进程；脚本核对通过标记、结果字段与两种工具的一致性，并保存原始日志。

## 定向结果

**28 个定向运行均通过**：2 种仿真器 ×（7 个 RAM 独立测试 + 7 个 MBIST 集成测试）。集成测试中每轮独立 Checker 均接受完整 640 笔请求；故障案例按预期合理地返回 FAIL。以下为两种工具一致的结果：

| 配置 | 激活次数 | 读比较错误数 | 首错阶段/地址 | 期望/实际 |
| --- | ---: | ---: | --- | --- |
| 无故障，7/2 | 0 | 0，PASS | — | — |
| SA0，7/2 | 2 | 2 | M2 / 7 | FF / FB |
| SA1，7/2 | 3 | 3 | M1 / 7 | 00 / 04 |
| Rising TF，7/2 | 2 | 2 | M2 / 7 | FF / FB |
| Falling TF，7/2 | 2 | 2 | M3 / 7 | 00 / 04 |
| SA0，63/7 | 2 | 2 | M2 / 63 | FF / 7F |
| Falling TF，0/0 | 2 | 2 | M3 / 0 | 00 / 01 |

完整复现命令、CSV 报告及原始日志见 [`../results/step05/README.md`](../results/step05/README.md)。SA0 与 Rising TF 在所选 March 序列上有相同的首错结果，但独立 RAM 测试证明二者激活条件不同；不能仅凭 MBIST 的 FAIL 判定模型正确。

## 范围

v5 使用 7 个定向配置检查故障行为；完整的 2,048 实例结果见 v6，覆盖率统计见 v7。`fault_activated`、MBIST 检出及仿真有效性分别记录。本模型是功能仿真中的单故障抽象，不代表真实 FPGA BRAM 的物理缺陷注入。

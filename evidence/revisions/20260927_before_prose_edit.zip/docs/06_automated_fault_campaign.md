# v6：自动化故障注入实验

**v6 · 09.18–09.21**。完成 2,048 个单故障实例的双工具实验。清单、结果和原始日志见[v6 证据](../results/step06/README.md)。

## 范围与方法

故障集合为 v5 的 SA0、SA1、Rising TF、Falling TF，固定 64 地址、8 位，每次配置一个故障。`scripts/generate_fault_manifest.py` 按故障类型、地址、位的顺序生成 2,048 个唯一配置和 `F0000`～`F2047` 编号；四类各 512 个。`fault_manifest.csv` 是实验全集，`pilot_manifest.csv` 选取每类 8 个不同地址及位位置，共 32 个试运行实例。

`scripts/run_step06.py` 分别构建 Icarus 和 XSim 快照，每个工具编译一次，默认每 64 个实例运行一个仿真进程。每个实例开始时，Testbench 使用实验端口 `experiment_clear` 把故障 RAM 单元、读响应和参考模型状态恢复到未初始化状态，再复位控制器和 checker，并验证激活计数、响应及 DONE 状态已清零。普通 `rst_n` 仍保留存储器数据。正式 `rtl/` 控制器未改。完整序列由 v4 独立事务 checker 按规格核对；v5 参考监视器核对读值和激活事件。

运行器保留每个仿真进程的运行日志；结构化记录中的 `raw_log` 和 `raw_log_sha256` 可定位并验证对应日志。若整块运行异常、超时或缺失关键标记，运行器二分重试到单实例，并记录无效实例及原因。失败不会被当作故障检出。`simulation_status` 表示仿真记录有效性；`outcome` 区分 `activated_detected`、`activated_escape`、`not_activated` 和 `invalid`。检测信号出现但无激活证据也归为无效。覆盖率统计和分母定义见[v7 报告](07_fault_coverage_evaluation.md)。

## 验收结果

| 项目 | 结果 |
| --- | ---: |
| 故障清单 | 2,048 个唯一实例，四类各 512 |
| 试运行 | 32 个实例 × 2 工具 = 64 条有效记录 |
| 全量运行 | 2,048 个实例 × 2 工具 = 4,096 条有效记录 |
| 全量无效记录 | 0 |
| 两工具结构化字段分歧 | 0 / 2,048 对 |
| 全量激活且检出记录 | 4,096 |
| 每实例请求数 | 640 |
| 每实例执行周期 | 960（本 Testbench 的 DONE 等待计数） |

两工具的每个实例均有实际激活事件、故障检出、首次失败诊断、完整 640 笔请求和正常结束记录。`scripts/audit_step06.py` 独立检查清单、记录数量、工具配对、日志哈希和原始标记；单实例重放与全量结果比对也通过。以上只针对当前四类**定义明确的单故障仿真模型**，不代表真实 BRAM 或所有物理存储器故障的覆盖率。

## 证据与复现

清单、CSV/JSONL、按工具保存的原始日志、构建日志、源码 SHA-256、审计结果和复现命令见 [`results/step06/README.md`](../results/step06/README.md)。完整实验使用 `py -3 scripts/run_step06.py --mode all`，单实例使用 `py -3 scripts/run_step06.py --mode replay --fault-id F1023 --tool both`；审计使用 `py -3 scripts/audit_step06.py`。运行时需安装并可调用本项目固定版本的 Vivado 2018.3 XSim 与 Icarus Verilog。

当前运行目录及 `MBIST_AUDIT_RUN_ID` 设置见[复现说明](reproduce.md)，审计新实验时需选择相同运行编号。

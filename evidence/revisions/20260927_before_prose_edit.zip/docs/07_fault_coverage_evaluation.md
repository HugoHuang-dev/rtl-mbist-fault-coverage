# v7：Fault Coverage Evaluation

**v7 · 09.22–09.23**。独立分析 v6 的原始结果，得到分类覆盖率和首检阶段分布。统计文件见[v7 证据](../results/step07/README.md)。

## 1. 数据来源与独立审计

权威目标集合为 [`fault_manifest.csv`](../results/step06/fault_manifest.csv)：四类故障、64 个地址、8 个数据位，按唯一 `fault_id` 构成 2,048 个实例。v6 全量 [`raw_results.csv`](../results/step06/full/raw_results.csv) 有 XSim 和 Icarus 各 2,048 条，共 4,096 条**工具记录**；覆盖率分母只计 2,048 个唯一实例。v1 冻结的 [`march_c_minus_64x8.csv`](../specs/march_c_minus_64x8.csv) 给出理论请求序列。

[`evaluate_fault_coverage.py`](../scripts/evaluate_fault_coverage.py) 不调用仿真器。它重新检查清单的编号与配置全集、每个实例是否有两份唯一记录、激活和检测标志与事件/错误次数、首错诊断、640 笔请求及执行周期。它验证 v6 20 个源码指纹和 64 份原始批次日志的 SHA-256，并从日志中的 `CASE_BEGIN`、`FAULT_ACTIVATE`、`CHECKER_PASS`、`CASE_RESULT` 逐例复核结构化 CSV。最后独立比较两工具字段，再与 v6 `summary.json`、`consistency.csv`、`audit.json` 对账。将一条结果的首检阶段人为改错时，脚本报出 `CSV differs from raw result` 并拒绝该记录。

本报告采用保守的**确认检出**口径：同一个故障在两种工具中都运行有效、确实激活、被检出，且关键结果字段一致，才计入分子。固定目标集合始终是分母；未激活、激活未检出、仿真无效及工具结果不一致分别保留为异常项，不静默删除，也不把无效仿真当作成功。公式为：

\[
FC_{\mathrm{target}} = \frac{\text{双工具一致确认检出的唯一故障实例数}}
{\text{预定目标故障实例数}} \times 100\%.
\]

## 2. 分类结果

| 故障类型 | 目标实例 | 确认检出 | 目标集合覆盖率 | 未激活 | 激活未检出 | 仿真无效 | 工具分歧 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| SA0 | 512 | 512 | 100.00% | 0 | 0 | 0 | 0 |
| SA1 | 512 | 512 | 100.00% | 0 | 0 | 0 | 0 |
| Rising TF | 512 | 512 | 100.00% | 0 | 0 | 0 | 0 |
| Falling TF | 512 | 512 | 100.00% | 0 | 0 | 0 | 0 |
| **总计** | **2,048** | **2,048** | **100.00%** | **0** | **0** | **0** | **0** |

仿真失败归入仿真无效，本轮数量为 0。逐故障分类见[`fault_evaluation.csv`](../results/step07/fault_evaluation.csv)，异常清单见[`exceptions.csv`](../results/step07/exceptions.csv)；后者本轮只有表头。汇总见[`coverage_by_type.csv`](../results/step07/coverage_by_type.csv)。

## 3. Fault Detection Stage Matrix

| 故障类型 | M0 | M1 | M2 | M3 | M4 | M5 | 合计 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| SA0 | 0 | 0 | 512 | 0 | 0 | 0 | 512 |
| SA1 | 0 | 512 | 0 | 0 | 0 | 0 | 512 |
| Rising TF | 0 | 0 | 512 | 0 | 0 | 0 | 512 |
| Falling TF | 0 | 0 | 0 | 512 | 0 | 0 | 512 |
| **总计** | **0** | **512** | **1,024** | **512** | **0** | **0** | **2,048** |

该分布与所定义故障行为及 March C− 顺序一致。SA1 在 M0 写 0 时暴露，随后 M1 的 `r0` 首次检出；SA0 与 Rising TF 在 M1 的写 1 后，由 M2 的 `r1` 首次检出；Falling TF 在 M2 的写 0 后，由 M3 的 `r0` 首次检出。M0 只有写操作，所以没有首次读比较检出。对每一类，全部 64 个地址和 8 个数据位的首次检测阶段相同；2,048 个实例的首次失败地址也都等于注入地址。逐例证据与机器可读矩阵分别见 [`fault_evaluation.csv`](../results/step07/fault_evaluation.csv) 和 [`detection_stage_matrix.csv`](../results/step07/detection_stage_matrix.csv)。

## 4. 测试效率与周期口径

v1 定义的 March C− 总操作数为 `10N = 640`，其中读 320、写 320；M0/M5 各 64 笔，M1～M4 各 128 笔。v6 的 4,096 条有效工具记录全部为 640 笔请求，并且都记录 960 个执行周期。故本轮记录的平均值为 **1.5 周期/请求**（约 0.667 请求/周期），周期数比操作数多 320。差值包含同步读响应等待及控制调度，不能直接解释成额外 RAM 操作。按项目 50 MHz 标称时钟换算，960 周期对应约 19.2 µs 的仿真计数区间；这不是板级实测延迟。

v6 的 `cycles` 从 `start` 被采样后、Testbench 取消 `start` 的那个下降沿开始，数到观察到 `DONE`。v3 Testbench 把启动采样沿也计入，故记录为 961 拍；两者差一拍来自计数起点，640 笔 RAM 请求数相同。机器可读的周期定义和统计见 [`efficiency.json`](../results/step07/efficiency.json)。

## 5. 结论范围与复现

**100.00% 仅适用于本项目 64×8 bit 仿真 RAM、四类单故障模型及穷举的 2,048 个目标配置。**该结果支持控制器、故障模型和自动化验证流程在定义范围内的正确性；不包含 Coupling Fault、Retention Fault 等其他故障，也不代表物理存储器总体故障覆盖率。FPGA 板级结果独立记录在 v9。

在项目根目录执行 `py -3 scripts/evaluate_fault_coverage.py` 即可从 v6 证据重建本轮统计；不需要启动 XSim 或 Icarus。输出文件、审计与哈希清单见 [`results/step07/README.md`](../results/step07/README.md)。

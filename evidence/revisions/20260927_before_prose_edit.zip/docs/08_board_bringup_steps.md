# v9 上板操作手册

达芬奇 XC7A35TFGG484-2I，Vivado 2018.3。正常与受控异常的[实测资料](../results/step08/hardware_final/README.md)已归档。

## 准备与连接

1. 连接电源和 JTAG，核对芯片与目标器件。板级引脚见[约束](../fpga/board_pins.xdc)。
2. 启动 Vivado 2018.3，打开 Hardware Manager → Open Target → Auto Connect，确认 `xc7a35t`。
3. 使用[发布目录](../releases/20260926_review/README.md)中的位流。无需重新综合即可下载已有位流。

| 配置 | Bitstream | Debug Probes |
| --- | --- | --- |
| 正常 LED | `releases/20260926_review/normal_led.bit` | 留空 |
| 正常 ILA | `releases/20260926_review/normal_ila.bit` | 同目录 `normal_ila.ltx` |
| 扰动 LED | `releases/20260926_review/fault_led.bit` | 留空 |
| 扰动 ILA | `releases/20260926_review/fault_ila.bit` | 同目录 `fault_ila.ltx` |

在器件上右键 Program Device，选择配套文件，下载后确认 Programmed。正常与扰动的 `.bit/.ltx` 必须分别配对。

## 正常 LED 测试

1. 下载正常 LED 位流，按 RESET 后松开，LED0～3 应全灭。
2. 按 KEY0 约 0.1～0.3 秒，超过约 10 ms 去抖时间。完成后 LED0/DONE、LED1/PASS 亮，LED2/FAIL、LED3/BUSY 灭。
3. 不复位再次按 KEY0，测试重新执行并返回 PASS。
4. 按 RESET 清除结果，再按 KEY0，确认重新完成。

MBIST 的运行约 19 µs，BUSY 灯可能无法肉眼观察。对应照片见[复位清零](../results/step08/hardware_final/photos/05_normal_reset_clears_result.jpg)和[复位后重启](../results/step08/hardware_final/photos/06_normal_pass_after_reset.jpg)。

## 正常 ILA 采集

1. 下载正常 ILA 位流和配套探针，展开 `hw_ila_1`。
2. 设置 1024 点采样，Trigger Position=0，触发条件 `start_pulse == 1`。保持连续采样，不设置存储条件过滤。
3. 点 Run Trigger，再按 KEY0。保存完整原生 `.ila`，并截取末端 DONE/PASS。
4. 再次点 Run Trigger，不复位直接按 KEY0，保存第二轮；另按 RESET 后重新采集一轮。
5. 核对最终 `accepted_count=640, done=1, pass=1, fail=0, error_count=0, busy=0`。

显示格式：计数、阶段、地址采用 Unsigned Decimal；数据采用 Hexadecimal；单比特采用 Binary。正常六阶段请求数为 64/128/128/128/128/64。

## 受控异常测试

1. 下载 `fault_led.bit`，按 RESET、KEY0。完成后 LED0/DONE、LED2/FAIL 亮，LED1/PASS、LED3/BUSY 灭。
2. 下载 `fault_ila.bit` 与 `fault_ila.ltx`，按正常配置的方法设置采集并启动。
3. 查看样点 279～280：M2、地址 7 的读响应由 FF 变为 FE，随后 `fail=1`、错误数 1，首错阶段 2、地址 7、期望 FF、实际 FE。
4. 查看末端：请求数 640、DONE=1、PASS=0、FAIL=1、BUSY=0。确认异常后仍运行至 M5 完成。
5. 不复位，重新 Run Trigger、按 KEY0，保存第二轮。新轮启动清除旧诊断，随后再次得到同一首错及完成状态。

该配置通过包装逻辑改变一次读响应，测试 FAIL 和诊断通路。恢复正常演示时重新下载正常位流。

## 保存与核对

保留原生 `.ila`、末端状态截图、首错局部截图和对应板卡灯态照片。已归档文件的命名、内容和校验值见[证据索引](../results/step08/hardware_final/README.md)。

在项目根目录执行以下命令，可重新审计已归档采集：

```powershell
py -3 scripts/audit_final_hardware.py
$env:MBIST_RUN_ID = '20260926_review_final'
py -3 scripts/audit_board_revision.py
```

[最终资源与时序报告](../results/reruns/20260926_review_final/README.md) · [硬件审计 JSON](../results/step08/hardware_final/audit.json)

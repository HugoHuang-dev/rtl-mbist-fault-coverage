# MBIST ASIC 扩展工作流 · V10–V13

更新：2026-09-27。当前状态：V10–V13 已通过；V13 完成面积与综合阶段 STA 评估，原始报告、截图和最终审计已归档，Phase I 基线已冻结。

## 工作范围与工程位置

- 开发基线：`C:\Users\32035\Documents\Codex\2026-09-26\new-chat\outputs\mbist-fault-coverage`（本目录）。
- 最终整合目标：`C:\Users\32035\Desktop\FPGA\ProjectIII`。V10–V13 全部完成、Milestone A 验收后，再将增量成果整合进去。
- 本阶段交付独立 MBIST ASIC 顶层、可复现的 Nangate45 综合配置、经过功能验证的标准单元网表、面积和综合阶段时序报告。
- SRAM 保留在顶层外部；FPGA BRAM、板级按键/LED、ILA 和 FPGA 专用 IP 不进入 ASIC 综合清单。
- V14–V18 Controller-only RTL-to-GDS 暂不开展。官方 GCD 的 GDS 仅用于环境检查。

## 版本口径

以用户重新提交的顺延规划为准：**原有 V1–V9 全部保持不变**，V9 继续表示真实板卡验证；本次 ASIC 扩展为 **V10–V13**。后续可选物理实现为 V14–V18。最初草案中的 ASIC V9–V12 已被新计划取代，不重分配历史版本号。

## Development Workflow：环境准备（不计入版本）

2026-09-27 验收的开发环境：Windows 11 + WSL 2.7.14.0 / Ubuntu 24.04.5 LTS（WSL2）+ Docker CLI/Engine 29.8.0；ORFS commit `b74a7293ea57fc4154a08471bcf78042ed497e4e`，由 `ORFS_IMAGE` 指定预构建镜像；容器内 Yosys `0.68+post`，OpenROAD 版本字符串为 `unknown`，可运行 Tcl。ORFS 检出是浅克隆，源码子模块未初始化；本阶段使用预构建镜像运行工具。

复现入口：在 WSL 的 `~/OpenROAD-flow-scripts` 中运行 `docker run --rm -it -u "$(id -u):$(id -g)" -v "$PWD/flow:/OpenROAD-flow-scripts/flow" "$ORFS_IMAGE"`；容器中执行 `source ./env.sh`、`cd flow`，再用 `make DESIGN_CONFIG=./designs/nangate45/gcd/config.mk` 复查官方示例。实际用于 MBIST 的配置、SDC、库条件和运行命令已在 V11–V13 固定。

环境验收依据：GCD 流程退出码 0，综合报告及网表可读取，`results/nangate45/gcd/base/6_final.gds` 非空。该示例有 setup 违例，也未做独立签核 DRC/LVS；它仅证明工具链可运行，不是 MBIST 的面积、时序或物理实现数据。详细安装和 GCD 记录可保留本地，项目中保留上述影响复现的版本及配置。

## Project Workflow

| 版本 | 内容 | 验收与交付 | 状态 |
| --- | --- | --- | --- |
| ASIC V10 | ASIC-Oriented MBIST Architecture Design | 复用现有核心，新增 `mbist_asic_top.v`；独立文件清单、架构图、Vivado RTL 层级/原理图、接口规格；正常与故障定向回归通过，640 请求及首错诊断不变 | **完成**，见[设计文档](docs/10_asic_architecture.md)和[图像及回归证据](results/asic/v10/README.md) |
| ASIC V11 | ASIC Design Configuration & Timing Constraints | Nangate45 `config.mk`、`constraint.sdc`；50 MHz / 20 ns；明确接口输入/输出延迟、负载、时钟假设和同步复位处理，检查意外未约束路径 | **完成**，见[约束文档](docs/11_asic_constraints.md)和[检查证据](results/asic/v11/README.md) |
| ASIC V12 | Standard-Cell Synthesis & Netlist Verification | Yosys 标准单元映射、综合日志审查、综合网表；加载匹配的单元模型进行功能回归 | **完成**，见[综合与验证文档](docs/12_asic_synthesis.md)和[证据](results/asic/v12/README.md) |
| ASIC V13 | Synthesis Area & Timing Evaluation | 264 个单元、483.322 µm²、Setup WNS +17.3953 ns；首错诊断关键路径与约束、互连模型分析 | **完成**，见[评估文档](docs/13_synthesis_evaluation.md)与[报告及截图](results/asic/v13/README.md) |

正式项目文档分别为 `docs/10_asic_architecture.md`、`docs/11_asic_constraints.md`、`docs/12_asic_synthesis.md`、`docs/13_synthesis_evaluation.md`，在各版本实施时创建。与设计直接相关的实施过程、实际错误、定位、修复及复验结果保留在对应版本文档中；不只记录最终成功结论。

### ASIC V10 实施与验证

1. 核对[基线清单](asic/devlog/baseline_20260927.csv)；原有 RTL、TB、规格与脚本未改动，README 仅增加 ASIC 扩展入口。
2. 新增透传原有接口的 [ASIC 包装顶层](asic/rtl/mbist_asic_top.v)，复用 `mbist_top` 和五个子模块；[综合文件清单](asic/rtl/asic_rtl.f)只列控制器文件。
3. 复用冻结的 640 行 CSV、外部 RAM 和独立 Checker，在 Icarus 与 XSim 上分别对原顶层和 ASIC 顶层执行正常、定向扰动及七个故障场景。每工具 16 场景均通过，原顶层与 ASIC 顶层外部结果一致；两工具 ASIC 结果一致。
4. 使用同一七文件清单建立 Vivado 2018.3 RTL 查看工程，展开 `mbist_asic_top` 并归档顶层接口、五个模块连线及层级/源码三张原始截图。
5. 保存编译/运行日志、事务核对结果。架构图、接口规格、实施排查见[正式 V10 文档](docs/10_asic_architecture.md)。

V10 未重新设计 March C−，验收固定既有 64×8 配置。

### ASIC V11 配置与约束

在 [`asic/config/config.mk`](asic/config/config.mk) 指定控制器顶层、Nangate45 和 V10 文件清单，在 [`constraint.sdc`](asic/config/constraint.sdc) 建立 20 ns 同步时钟与外部存储器接口的明确预算：输入/输出延迟 0–2 ns、输出负载 4 fF，`rst_n` 按同步输入分析。ORFS 初步综合与 SDC 解析通过；展开的 SDC 覆盖全部 12 个非时钟输入位和 54 个输出位，九组重点路径可报告且未设置时序例外。数值为早期集成假设，具体依据、调试过程和冻结证据见 [V11 文档](docs/11_asic_constraints.md)。

### ASIC V12 标准单元综合与网表验证

V12 已按 V11 冻结配置在独立 WSL ext4 工作区正式综合，Nangate45 网表通过 Yosys 0 问题结构检查。使用同一 Liberty 生成零延迟单元功能模型，并让原独立 Checker 对网表执行双轮正常/定向读扰动及七个故障场景；Icarus 与 XSim 共 16 个场景通过，全部事务与 V10 外部结果一致。XSim 2018.3 所需的 `timescale` 只加在仿真副本。正式网表、日志、模型与复现命令见 [V12 文档](docs/12_asic_synthesis.md)和[证据索引](results/asic/v12/README.md)。

### ASIC V11–V13 的执行约定

- 综合文件清单显式列举，不用涵盖整个 `rtl/` 的通配符把 RAM 带入综合。
- `rst_n` 为低有效**同步**复位，不能直接套用异步复位的 false-path 模板。时序例外须有实际依据。
- 时序约束覆盖 `start`、`req_ready`、`rd_valid/rd_data`、请求输出、状态与诊断输出；输入/输出延迟和负载在 V11 明确数值及来源，不把 20 ns 时钟周期当作完整接口约束。
- V12 优先复用冻结事务表和独立 Checker，不默认重跑全部 2,048 故障实例。门级功能仿真须明确复位、模型来源和是否含时延；功能通过不代替 STA。
- V13 报告综合阶段结果。WNS、路径延迟的定义、起终点和路径类型须明确；存在外部延迟等约束时，不机械地用 `20 ns - WNS` 充当内部逻辑延迟或最高频率。
- 面积范围为控制器标准单元，不包含 SRAM、IO pad 或完整芯片面积；不与 FPGA LUT/BRAM 数量直接等同。

## 产物与整合约定

ASIC 顶层/文件清单位于 `asic/rtl/`，ORFS 配置位于 `asic/config/`，验证入口位于 `asic/scripts/`，内部记录位于 `asic/devlog/`。

新实验日志、报告和网表使用 `results/asic/<version>/<run_id>/`；构建临时文件使用独立目录。原工程脚本会写入既有 `results/stepXX`，ASIC 回归需另建运行入口，避免直接调用旧脚本覆盖历史结果。归档时核查 `.gitignore`，确保日志和报告实际纳入交付。

Milestone A 达成后再整合：保留 ProjectIII 已有的路径配置、发布证据、板级改进和工具记录，只迁入经审查的 ASIC 增量及相应文档链接；在整合目录复跑必要验证，冻结网表、报告、配置。本地两份目录当前均未发现 Git 仓库元数据，后续还需把成果关联到实际 GitHub 仓库与发布 commit。

## 参考

- [ORFS Docker 示例](https://openroad-flow-scripts.readthedocs.io/en/latest/user/DockerShell.html)
- [ORFS 新设计接入](https://openroad-flow-scripts.readthedocs.io/en/latest/user/AddingNewDesign.html)
- [ORFS 流程参数](https://openroad-flow-scripts.readthedocs.io/en/latest/user/FlowVariables.html)
- [ORFS Makefile](https://github.com/The-OpenROAD-Project/OpenROAD-flow-scripts/blob/master/flow/Makefile)：2026-09-27 查阅的版本包含 `synth` 和 `synth-report`。执行时以环境中固定的 commit 为准。

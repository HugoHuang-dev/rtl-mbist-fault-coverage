"""Audit the frozen V13 area, STA paths, and original screenshot evidence."""

import argparse
import json
import re
from decimal import Decimal
from pathlib import Path


SCREENSHOTS = (
    "01_yosys_synthesis_statistics.png",
    "02_area_liberty_reconciliation.png",
    "03_critical_setup_path_detailed.png",
    "05_openroad_analysis_conditions.png",
    "06_register_to_register_path.png",
    "07_critical_setup_path_compact.png",
    "08_register_to_output_path.png",
)


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def path_metrics(path):
    report = path.read_text(encoding="utf-8")
    def match(pattern):
        value = re.search(pattern, report, re.MULTILINE)
        check(value is not None, f"Missing {pattern} in {path}")
        return value.group(1)
    return {
        "startpoint": match(r"^Startpoint: (.+)$"),
        "endpoint": match(r"^Endpoint: (.+)$"),
        "arrival_ns": match(r"^\s*([0-9.]+)\s+data arrival time\s*$"),
        "required_ns": match(r"^\s*([0-9.]+)\s+data required time\s*$"),
        "slack_ns": match(r"^\s*([0-9.]+)\s+slack \(MET\)\s*$"),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path)
    run = parser.parse_args().run_dir.resolve()
    preflight = json.loads((run / "preflight.json").read_text(encoding="utf-8"))
    area = json.loads((run / "area_summary.json").read_text(encoding="utf-8"))
    prep = json.loads((run / "preparation_audit.json").read_text(encoding="utf-8"))
    check(all(item["status"] == "PASS" for item in (preflight, area, prep)),
          "An upstream V13 audit did not pass")
    check(prep["check_setup_diagnostics"] == 0 and
          prep["unconstrained_path_group_count"] == 0,
          "STA setup or constraint audit failed")
    check(area["cell_count"] == area["sequential_count"] + area["combinational_count"],
          "Cell counts do not reconcile")
    check(Decimal(area["total_area_um2"]) ==
          Decimal(area["sequential_area_um2"]) + Decimal(area["combinational_area_um2"]),
          "Area components do not reconcile")
    check(area["cell_count"] == 264 and area["sequential_count"] == 42,
          "Frozen V12 structure differs")
    check(Decimal(area["total_area_um2"]) == Decimal("483.322000"),
          "Area differs from Yosys report")

    wns = re.fullmatch(r"worst slack max ([0-9.]+)\s*",
                       (run / "sta/setup_wns.rpt").read_text(encoding="utf-8"))
    check(wns is not None, "Cannot parse setup WNS")
    paths = {kind: path_metrics(run / "sta" / filename) for kind, filename in (
        ("critical", "setup_top10.rpt"),
        ("register_to_register", "reg_to_reg.rpt"),
        ("register_to_output", "reg_to_output.rpt"),
    )}
    critical = paths["critical"]
    check(Decimal(wns[1]) == Decimal(critical["slack_ns"]),
          "WNS differs from the worst setup path")
    check(critical["startpoint"].startswith("rd_data[7] (") and
          "first_fail_actual[5]" in critical["endpoint"],
          "Critical path identity differs")
    check(Decimal(critical["arrival_ns"]) == Decimal("2.3656") and
          Decimal(critical["required_ns"]) - Decimal(critical["arrival_ns"]) == Decimal(wns[1]),
          "Critical path timing arithmetic differs")
    top = (run / "sta/setup_top10.rpt").read_text(encoding="utf-8")
    input_delay = re.search(r"^\s*([0-9.]+)\s+[0-9.]+ v input external delay\s*$",
                            top, re.MULTILINE)
    check(input_delay is not None and Decimal(input_delay[1]) == Decimal("2.0000"),
          "External input delay differs")
    check(Decimal(paths["register_to_register"]["arrival_ns"]) == Decimal("0.5270") and
          Decimal(paths["register_to_output"]["arrival_ns"]) == Decimal("0.2888"),
          "Category path reports differ")
    check(not (run / "sta/check_setup.rpt").read_text(encoding="utf-8").strip(),
          "check_setup contains diagnostics")

    for name in SCREENSHOTS:
        image = run / "screenshots" / name
        raw = image.read_bytes()
        check(raw[:8] == b"\x89PNG\r\n\x1a\n" and len(raw) > 10000,
              f"Invalid screenshot: {name}")

    result = {
        "status": "PASS",
        "basis": "V12 accepted gate-level netlist; V11 SDC; Nangate45 typical Liberty",
        "area": {key: area[key] for key in (
            "cell_count", "sequential_count", "combinational_count", "total_area_um2",
            "sequential_area_um2", "combinational_area_um2")},
        "target_clock_ns": "20.0000",
        "setup_wns_ns": wns[1],
        "critical_path": {
            **critical,
            "external_input_delay_ns": input_delay[1],
            "controller_data_delay_ns": str(Decimal(critical["arrival_ns"]) - Decimal(input_delay[1])),
            "function": "read-response first-failure diagnostic capture",
        },
        "category_paths": {key: value for key, value in paths.items() if key != "critical"},
        "check_setup_diagnostics": 0,
        "unconstrained_path_group_count": 0,
        "interconnect_model": prep["interconnect_model"],
    }
    (run / "final_audit.json").write_text(json.dumps(result, indent=2) + "\n",
                                           encoding="utf-8")
    print("V13_FINAL_AUDIT_PASS", run / "final_audit.json")


if __name__ == "__main__":
    main()

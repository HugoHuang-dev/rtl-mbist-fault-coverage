#!/usr/bin/env bash
# Run from WSL Ubuntu. This mounts the local MBIST project beside the frozen
# ORFS flow and keeps all new output under results/asic/v11/<run-id>/.
set -euo pipefail

run_id="${1:-$(date +%Y%m%d_%H%M%S)}"
if [[ ! "$run_id" =~ ^[A-Za-z0-9_-]+$ ]]; then
  printf 'Invalid run ID: %s\n' "$run_id" >&2
  exit 2
fi

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
orfs_root="${ORFS_ROOT:-$HOME/OpenROAD-flow-scripts}"
work_host="$HOME/mbist-asic-work/v11/$run_id"
image='openroad/orfs@sha256:bc05b68ef2f023cb49d4a7f80b021d3895328c0e4ee8491ae9bdf6fc29771b9f'
test -f "$orfs_root/flow/Makefile"
test -f "$project_root/asic/config/config.mk"
out="$project_root/results/asic/v11/$run_id"
mkdir -p "$(dirname "$out")"
mkdir "$out"
mkdir -p "$work_host"

docker run --rm -u "$(id -u):$(id -g)" \
  -v "$orfs_root/flow:/OpenROAD-flow-scripts/flow" \
  -v "$project_root:/work/mbist:ro" \
  -v "$work_host:/work/output" \
  -w /OpenROAD-flow-scripts "$image" bash -lc '
    set -euo pipefail
    source ./env.sh
    cd flow
    config=/work/mbist/asic/config/config.mk
    work=/work/output
    for var in DESIGN_NAME PLATFORM VERILOG_FILES SDC_FILE ABC_CLOCK_PERIOD_IN_PS; do
      make DESIGN_CONFIG="$config" WORK_HOME="$work" "print-$var"
    done
  ' 2>&1 | tee "$out/config_parse.log"

docker run --rm -u "$(id -u):$(id -g)" \
  -v "$orfs_root/flow:/OpenROAD-flow-scripts/flow" \
  -v "$project_root:/work/mbist:ro" \
  -v "$work_host:/work/output" \
  -w /OpenROAD-flow-scripts "$image" bash -lc '
    set -euo pipefail
    source ./env.sh
    cd flow
    make DESIGN_CONFIG=/work/mbist/asic/config/config.mk \
      WORK_HOME=/work/output synth
  ' 2>&1 | tee "$out/synth_validation.log"

docker run --rm -u "$(id -u):$(id -g)" \
  -v "$orfs_root/flow:/OpenROAD-flow-scripts/flow" \
  -v "$project_root:/work/mbist:ro" \
  -v "$work_host:/work/output" \
  -e V11_WORK=/work/output \
  -w /OpenROAD-flow-scripts "$image" bash -lc '
    set -euo pipefail
    source ./env.sh
    openroad -exit /work/mbist/asic/scripts/check_v11.tcl
  ' 2>&1 | tee "$out/constraint_check.log"

mkdir "$out/orfs"
cp -r "$work_host/results" "$work_host/logs" "$work_host/reports" "$out/orfs/"
mkdir "$out/input_snapshot"
cp "$project_root/asic/config/config.mk" "$project_root/asic/config/constraint.sdc" \
   "$project_root/asic/rtl/asic_rtl.f" "$out/input_snapshot/"
cp "$project_root/asic/scripts/run_v11.sh" "$project_root/asic/scripts/check_v11.tcl" \
   "$project_root/asic/scripts/audit_v11.py" "$out/input_snapshot/"
{
  printf 'ORFS_COMMIT %s\n' "$(git -C "$orfs_root" rev-parse HEAD)"
  printf 'ORFS_IMAGE %s\n' "$image"
  sha256sum "$orfs_root/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib"
  sha256sum "$project_root/asic/config/config.mk" "$project_root/asic/config/constraint.sdc"
  while IFS= read -r relative; do
    [[ -z "$relative" || "$relative" == \#* ]] && continue
    sha256sum "$project_root/$relative"
  done < "$project_root/asic/rtl/asic_rtl.f"
} > "$out/toolchain.txt"
python3 "$project_root/asic/scripts/audit_v11.py" "$out"
printf 'V11 preliminary synthesis and SDC parse complete: %s\n' "$out"

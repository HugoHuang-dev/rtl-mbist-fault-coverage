"""Check that the V10 Vivado view project uses the frozen controller RTL."""

import hashlib
import json
import struct
from pathlib import Path
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parents[2]
XPR = ROOT / "asic/vivado/mbist_asic_v10/mbist_asic_v10.xpr"
EVIDENCE = ROOT / "results/asic/v10/vivado_view"
REFERENCE = ROOT / "results/asic/v10/20260927_icarus_v10/sources_sha256.json"
FILELIST = ROOT / "asic/rtl/asic_rtl.f"
SCREENSHOTS = {
    "01_asic_top_interface_schematic.png": "791b25f1debb02528eb8103f37aa587781dc002746e0173030f10e907f4eba04",
    "02_mbist_controller_rtl_schematic.png": "031442034c4b0201b2d07f9f335d18a52669776e282e51abd4a254278a70973a",
    "03_elaborated_hierarchy_and_rtl.png": "be879272cdf07c0eff426655eba2b5160c7936d2c25f1e4e34b514c3ed29de9c",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    names = [line.strip() for line in FILELIST.read_text().splitlines()
             if line.strip() and not line.lstrip().startswith("#")]
    if len(names) != 7:
        raise RuntimeError("V10 source list is not seven files")
    frozen = json.loads(REFERENCE.read_text(encoding="utf-8"))
    for name in names:
        if digest(ROOT / name) != frozen[name]:
            raise RuntimeError(f"V10 frozen source changed: {name}")
    tree = ElementTree.parse(XPR)
    source_set = next(item for item in tree.iter("FileSet") if item.get("Name") == "sources_1")
    actual = {Path(path.get("Path").replace("$PPRDIR", str(XPR.parent))).resolve()
              for path in source_set.iter("File")}
    expected = {(ROOT / name).resolve() for name in names}
    if actual != expected:
        raise RuntimeError("Vivado project source list differs from V10 file list")
    top = next(item.get("Val") for item in source_set.iter("Option")
               if item.get("Name") == "TopModule")
    part = next(item.get("Val") for item in tree.iter("Option")
                if item.get("Name") == "Part")
    if top != "mbist_asic_top" or part != "xc7a35tfgg484-2":
        raise RuntimeError("Vivado project top or view-only part differs")
    log = (EVIDENCE / "elaboration.log").read_text(encoding="utf-8", errors="replace")
    if ("V10_VIEW_ELABORATION_PASS top=mbist_asic_top" not in log or
            "0 Warnings, 0 Critical Warnings and 0 Errors" not in log):
        raise RuntimeError("RTL elaboration did not pass cleanly")
    screenshots = {}
    for name, expected_hash in SCREENSHOTS.items():
        path = EVIDENCE / "screenshots" / name
        raw = path.read_bytes()
        if digest(path) != expected_hash or raw[:8] != b"\x89PNG\r\n\x1a\n":
            raise RuntimeError(f"V10 screenshot changed: {name}")
        width, height = struct.unpack(">II", raw[16:24])
        screenshots[name] = {"sha256": expected_hash, "width": width, "height": height}
    result = {"status": "PASS", "purpose": "Vivado RTL elaboration view only",
              "top": top, "part": part, "rtl_file_count": len(names),
              "rtl_sha256": {name: digest(ROOT / name) for name in names},
              "project_sha256": digest(XPR),
              "elaboration_log_sha256": digest(EVIDENCE / "elaboration.log"),
              "create_script_sha256": digest(ROOT / "asic/scripts/create_v10_vivado_view.tcl"),
              "validate_script_sha256": digest(ROOT / "asic/scripts/validate_v10_vivado_view.tcl"),
              "screenshots": screenshots}
    (EVIDENCE / "audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("V10_VIVADO_VIEW_AUDIT_PASS")


if __name__ == "__main__":
    main()
